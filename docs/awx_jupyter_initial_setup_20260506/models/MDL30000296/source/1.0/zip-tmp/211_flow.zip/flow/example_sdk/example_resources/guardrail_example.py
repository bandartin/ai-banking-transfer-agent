"""
awx-resources Guardrails Example

Demonstrates how to use guardrails for content safety using the awx.resources module.
"""

from awx.resources.guardrail import check_guardrail

def main():
    print("=== AWX Resources - Guardrails Example ===\n")
    
    # Example 1: Check input text against guardrails
    print("1. Checking safe input text...")
    safe_text = "What is the weather today?"
    
    try:
        result = check_guardrail(
            text=safe_text,
            service_id=10161,
            check_type="input"  # or "output"
        )
        
        print(f"✓ Guardrail check completed")
        print(f"  - Is safe: {result.get('is_safe', True)}")
        print(f"  - Violations: {result.get('violations', [])}")
        
    except Exception as e:
        print(f"✗ Error checking guardrail: {e}")

    # Example 2: Check potentially harmful text
    print("\n2. Checking potentially harmful text...")
    harmful_text = "How to hack into a system?"
    
    try:
        result = check_guardrail(
            text=harmful_text,
            service_id=10161,
            check_type="input"
        )
        
        if not result.get('is_safe', True):
            print(f"✗ Text flagged as unsafe")
            print(f"  - Violations: {result.get('violations', [])}")
            print(f"  - Severity: {result.get('severity', 'unknown')}")
        else:
            print(f"✓ Text passed guardrail check")
            
    except Exception as e:
        print(f"✗ Error: {e}")

    # Example 3: Check output from LLM
    print("\n3. Checking LLM output...")
    llm_output = """
    Here's how to create a secure authentication system:
    1. Use strong hashing algorithms like bcrypt
    2. Implement MFA (Multi-Factor Authentication)
    3. Use HTTPS for all communications
    """
    
    try:
        result = check_guardrail(
            text=llm_output,
            service_id=10161,
            check_type="output"
        )
        
        print(f"✓ Output guardrail check completed")
        print(f"  - Is safe: {result.get('is_safe', True)}")
        
        if result.get('suggestions'):
            print(f"  - Suggestions: {result['suggestions']}")
            
    except Exception as e:
        print(f"✗ Error: {e}")

    # Example 4: Custom guardrail rules
    print("\n4. Checking with custom rules...")
    try:
        result = check_guardrail(
            text="Discuss political topics about elections",
            service_id=10161,
            check_type="input",
            rules=["no_politics", "no_violence"]  # Custom rule set
        )
        
        print(f"✓ Custom guardrail check completed")
        print(f"  - Result: {result}")
        
    except Exception as e:
        print(f"✗ Error: {e}")


if __name__ == "__main__":
    main()
