# LangGraph with OpenTelemetry 가이드

이 가이드는 LangGraph를 OpenTelemetry와 연동하는 방법을 설명합니다.

>ℹ️ **의존성 안내**: 시스템에 `awx-core`가 설치되어 있고 가상환경이 `--system-site-packages`로 생성된 경우, `pyproject.toml`의 의존성 목록에 `awx-core`가 없어도 런타임 import는 정상 동작합니다.

## 요구사항

- Python 3.11+
- uv (의존성 관리)
- OpenTelemetry Collector 또는 백엔드

## 설치 및 설정

### 1. 의존성 설치

```bash
uv sync
```

### 2. 환경 변수 설정

`.env.example` 파일을 `.env`로 복사하고 실제 값으로 수정:

```bash
cp .env.example .env
# .env 파일을 편집하여 실제 OpenTelemetry Collector 주소와 LLM API 키 설정
```

## 실행 방법

### 자동 계측 방식 (권장)

```bash
bash run-application.sh
```

또는 직접 실행:

```bash
uv run opentelemetry-instrument uvicorn app:app --host 0.0.0.0 --port 8000
```

## 코드 수정 사항

### 1. app.py

**추가해야 할 부분**:
- OpenTelemetry tracer import
- 시작 시 테스트 span 생성 (선택사항)

```python
from opentelemetry import trace

@asynccontextmanager
async def lifespan(app: FastAPI):
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("startup_connection_test") as span:
        span.set_attribute("service.startup", "true")
    yield
```

### 2. router.py

**수정 불필요**: `opentelemetry-instrumentation-langchain`이 자동으로 LangGraph 실행을 추적합니다.

LangGraph는 LangChain 위에 구축되므로, 기존 LangGraph 코드를 그대로 사용하면 됩니다:

```python
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import create_react_agent

# StateGraph 사용
workflow = StateGraph(GraphState)
workflow.add_node("chatbot", chatbot_node)
graph_app = workflow.compile()

# 또는 prebuilt agent 사용
agent_executor = create_react_agent(llm, tools)
result = agent_executor.invoke({"messages": messages})
# OpenTelemetry가 자동으로 추적
```

## 추적되는 정보

`opentelemetry-instrumentation-langchain`이 자동으로 수집하는 정보:

- LangGraph 그래프 실행 시간
- 각 노드(node) 실행 시간
- StateGraph의 상태 전환
- ReAct Agent의 의사결정 과정
- Tool 호출 (Tool 이름, 입력, 출력)
- LLM 호출 (model, temperature 등 파라미터)
- 에러 정보 (error.type, error.message)

## LangGraph 특화 추적

### StateGraph

StateGraph의 각 노드 실행이 자동으로 span으로 추적됩니다:

```python
workflow = StateGraph(GraphState)
workflow.add_node("node1", node1_func)  # 각 노드가 span으로 추적됨
workflow.add_node("node2", node2_func)
graph_app = workflow.compile()
```

### ReAct Agent

`create_react_agent`를 사용한 Agent 실행도 자동으로 추적됩니다:

```python
agent_executor = create_react_agent(llm, tools)
# Agent의 의사결정, Tool 호출, LLM 호출이 모두 추적됨
result = agent_executor.invoke({"messages": messages})
```

## 커스텀 계측 (선택사항)

특정 노드에 추가 정보를 기록하려면:

```python
from opentelemetry import trace

def custom_node(state: GraphState):
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("custom_node") as span:
        span.set_attribute("custom.attribute", "value")
        # 노드 로직 실행
        return result
```

## 테스트

서버 실행 후:

```bash
# 기본 채팅 테스트
curl -X POST http://localhost:8000/langraph/chat/basic \
  -H "Content-Type: application/json" \
  -d '{"message": "안녕하세요"}'

# ReAct Agent 테스트
curl -X POST http://localhost:8000/langraph/chat/agent \
  -H "Content-Type: application/json" \
  -d '{"message": "파이썬에 대해 검색해줘"}'

# 커스텀 그래프 테스트
curl -X POST http://localhost:8000/langraph/chat/custom-graph \
  -H "Content-Type: application/json" \
  -d '{"message": "안녕하세요", "topic": "프로그래밍"}'
```

## 폐쇄망 환경

폐쇄망 환경에서는 시스템에 이미 설치된 패키지(`/usr/local/lib/python3.11/dist-packages`)를 사용하도록 설정합니다.

**기본 동작**: `run-application.sh`가 자동으로 `--system-site-packages` 옵션을 사용하여 가상환경을 생성하므로, 시스템 패키지를 자동으로 사용합니다.

### 방법 1: 시스템 패키지 사용 (기본)

`run-application.sh`가 자동으로 시스템 패키지를 사용하는 가상환경을 생성합니다:
```bash
# 별도 설정 없이 실행하면 시스템 패키지 사용
bash run-application.sh
```

### 방법 2: 로컬 패키지 디렉토리 사용

1. **패키지 다운로드** (인터넷 접근 가능한 환경에서):
   ```bash
   # requirements.txt 생성
   uv export --format requirements-txt -o requirements.txt
   
   # pip를 사용하여 wheel 파일 다운로드 (uv pip download는 지원하지 않음)
   pip download -r requirements.txt -d ./local_packages
   ```

2. **폐쇄망 환경에서 사용**:
   ```bash
   # 환경 변수 설정
   export UV_LOCAL_PACKAGES="/path/to/local_packages"
   
   # 또는 .env 파일에 추가
   echo "UV_LOCAL_PACKAGES=/project/work/local_packages" >> .env
   
   # run-application.sh 실행
   bash run-application.sh
   ```

### 방법 2: Offline 모드 사용

로컬 캐시가 이미 있는 경우:
```bash
# 환경 변수 설정
export UV_OFFLINE=true

# 또는 .env 파일에 추가
echo "UV_OFFLINE=true" >> .env
```

### 방법 3: .env 파일에 설정

`.env` 파일에 다음을 추가:
```bash
# 로컬 패키지 디렉토리 지정 (권장)
UV_LOCAL_PACKAGES=/project/work/local_packages

# 또는 offline 모드 (로컬 캐시 사용)
UV_OFFLINE=true
```

`run-application.sh`가 자동으로 `--find-links` 또는 `--offline` 옵션을 사용합니다.

### 참고

- `.env` 파일에 OpenTelemetry Collector 주소 설정
- LLM API 키는 사용자 환경에 맞게 변경 (주석 참조)

## 참고

- LangGraph는 LangChain 위에 구축되므로 `opentelemetry-instrumentation-langchain`만으로 자동 추적됩니다
- 추가 코드 수정 없이 기존 LangGraph 코드가 자동으로 추적됩니다
- `openinference-*` 패키지는 사용하지 않습니다 (opentelemetry-*만 사용)
