# 사용자 가이드

이 가이드는 FastAPI 애플리케이션과 `sample_app.py` 스크립트에 대한 간략한 개요와 실행 지침을 제공합니다.

## FastAPI 애플리케이션

이 애플리케이션은 LLM 응답을 시뮬레이션하는 엔드포인트를 제공합니다. [route](./route.py) 파일에서 `/chat` 엔드포인트를 확인할 수 있으며, 이를 통해 배포 후 응답을 시뮬레이션할 수 있습니다. 응답 테스트에는 `ExampleClient`와 `LangchainClient` 두 가지 클라이언트 예제가 제공됩니다. `routes`의 `get_generator_client` 함수를 수정하여 필요에 따라 클라이언트를 선택하여 테스트할 수 있습니다. `LangchainClient`를 사용하려면 몇 가지 설정이 필요하며, 이 설정은 파일 형태로 저장되어 'AI Operation' 환경에 전달됩니다. 이러한 설정 파일 생성 예시를 담은 스크립트가 [sample_app.py](../../flow/sampleapp/sample_app.py)입니다.

>⚠️ **중요: `sample_app.py` 스크립트는 실제 애플리케이션을 'AI Operation' 환경에 배포하기 전에 반드시 실행해야 합니다.** 이 스크립트는 배포에 필요한 주요 구성 파일들을 생성합니다. 이 단계를 건너뛰면 애플리케이션이 올바르게 작동하지 않을 수 있습니다.

## 개요

이 샘플 스크립트는 Gen Text SDK를 사용하여 'AI Operation' 배포에 필요한 파일을 생성하는 방법을 안내합니다.

>ℹ️ **의존성 안내**: 시스템에 `awx-core`가 설치되어 있고 가상환경이 `--system-site-packages`로 생성된 경우, `pyproject.toml`의 의존성 목록에 `awx-core`가 없어도 런타임 import는 정상 동작합니다.

개발을 시작하기 전에 [가이드 노트북](../../../example/dap_gen/example.ipynb)을 통해 Gen Text SDK 사용법을 숙지하십시오.

가이드 노트북을 확인한 후, 이 `sample_app.py` 스크립트를 통해 실제 작동 방식을 파악할 수 있습니다.

## `sample_app.py` 정보

`sample_app.py` 스크립트는 GenAI Text Portal에서 LLM 및 Vector DB 서비스의 자격 증명을 검색하여 JSON 파일로 저장하는 과정을 보여줍니다. 이 스크립트를 실행하면 'AI Operation' 환경에 애플리케이션 배포에 필요한 자격 증명 및 리소스 정보 파일들이 생성됩니다.

## [샘플 애플리케이션](../../flow/sampleapp/sample_app.py) 실행하기

샘플 스크립트를 실행하려면 터미널에서 다음 명령을 입력하십시오:

```bash
python3 sample_app.py
```

스크립트 실행 후, `flow` 디렉터리에서 다음 파일들을 확인할 수 있습니다:

- `000_credentials.json`: LLM 및 Vector DB 서비스 자격 증명을 포함합니다.
- `external_resources_cache.json`: 외부 리소스 정보를 포함합니다.
- `prompts_cache.json`: 프롬프트 정보를 포함합니다.

이 파일들은 'AI Operation' 환경에 애플리케이션을 배포하는 데 사용됩니다.
