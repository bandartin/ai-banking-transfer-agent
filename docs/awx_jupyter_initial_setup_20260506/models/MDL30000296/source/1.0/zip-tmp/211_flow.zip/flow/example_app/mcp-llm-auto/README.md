# mcp-llm-auto

`mcp-llm-auto` example uses:
- MCP Server transport: `Streamable HTTP` (`/mcp/`)
- Inspector(optional): local UI + local proxy
- Client app: FastAPI + LangChain/LangGraph, calling MCP server via `MCP_SERVER_URL`
- MCP tools: `add`, `subtract`, `multiply`, `divide`

## Server Mode

From `example_awx/flow`:

```bash
make init mcp-llm-auto
make run
```

Default:
- App server: `http://<host>:8000`
- MCP endpoint: `http://<host>:8000/mcp/`

## Inspector (Server Mode)

Server mode can auto-start Inspector using `server/.env`.

Create env file:

```bash
cp example_app/mcp-llm-auto/server/.env.example example_app/mcp-llm-auto/server/.env
```

Key values:

```bash
MCP_INSPECTOR_ENABLED=true
MCP_INSPECTOR_HOST=0.0.0.0
MCP_INSPECTOR_PORT=5000
MCP_INSPECTOR_PROXY_PORT=6277
MCP_INSPECTOR_OMIT_AUTH=true
MCP_AUTO_OPEN_ENABLED=false
```

Access:
- Inspector UI: `http://<host>:5000`
- Inspector proxy health: `http://<host>:6277/health`

Inspector connection setting:
- Transport: `Streamable HTTP`
- URL: `http://<host>:8000/mcp/`
- Connection Type: `Via Proxy` (recommended)

## Client Mode

From `example_awx/flow`:

```bash
make init mcp-llm-auto.client
make run
```

Client mode uses `example_app/mcp-llm-auto/client`.

Set MCP server URL in `client/.env`:

```bash
cp example_app/mcp-llm-auto/client/.env.example example_app/mcp-llm-auto/client/.env
```

```bash
MCP_SERVER_URL=http://localhost:8001/mcp/
OPENAI_API_KEY=<your_key>
```

If server runs on `make run` default port (`8000`), use:

```bash
MCP_SERVER_URL=http://localhost:8000/mcp/
```

## E2E Check (Inspector -> Server)

1. Start server mode (`make init mcp-llm-auto && make run`).
2. Open Inspector UI.
3. Set transport/url as above.
4. Connect and verify tools list includes `add`, `subtract`, `multiply`, `divide`.
