#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8000}
UV_BIN=${3:-uv}

if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Client] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    # The AWX SDK is expected to be installed in system site-packages in real deployments.
    # Keep venv linked to system packages so `import awx` works without per-app wheel install.
    $UV_BIN venv --allow-existing --system-site-packages "$CUSTOM_VENV_PATH"
fi

echo "[Client] Starting AWX Observability MCP Client on $HOST:$PORT..."
$UV_BIN sync --no-install-project --inexact

if [ "${AWX_SMOKE:-0}" != "1" ]; then
    if ! $UV_BIN run --no-sync python -c "import awx.observability" >/dev/null 2>&1; then
        echo "[Client] ERROR: awx-observability SDK is not available in this environment."
        echo "[Client] Ensure the base image/system has awx SDK installed, then retry."
        exit 3
    fi
else
    echo "[Client] SMOKE: skipping awx-observability import check"
fi

load_env_defaults() {
    local env_file="$1"
    while IFS= read -r line || [ -n "$line" ]; do
        line="${line#"${line%%[![:space:]]*}"}"
        case "$line" in
            ""|\#*) continue ;;
        esac
        if [[ ! "$line" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
            continue
        fi
        local key="${line%%=*}"
        local value="${line#*=}"
        if [ -z "${!key+x}" ]; then
            export "$key=$value"
        fi
    done < "$env_file"
}

if [ -f .env ]; then
    # .env is treated as defaults. Runtime-injected env values must win.
    load_env_defaults ./.env
fi

# .env.example is treated as defaults only.
# Runtime-injected env values (pod/env vars) must win.
if [ -f .env.example ]; then
    load_env_defaults ./.env.example
fi

if [ -z "${OTEL_SERVICE_NAME:-}" ]; then
    RESOLVED_OTEL_SERVICE_NAME=$(
        $UV_BIN run --no-sync python - <<'PY'
import os

name = ""
try:
    from awx.observability.instrumentation.resource_attributes import build_resource_attributes
except Exception:
    print("")
    raise SystemExit(0)

try:
    attrs = build_resource_attributes()
    if isinstance(attrs, dict):
        value = attrs.get("service.name")
        if value is not None:
            name = str(value).strip()
except Exception:
    name = ""

print(name)
PY
    )

    if [ -n "$RESOLVED_OTEL_SERVICE_NAME" ]; then
        export OTEL_SERVICE_NAME="$RESOLVED_OTEL_SERVICE_NAME"
        # Keep SDK and auto-instrumentation aligned on the same service.name.
        export AWX_OTEL_SERVICE_NAME_OVERRIDE="${AWX_OTEL_SERVICE_NAME_OVERRIDE:-1}"
        echo "[Client] OTEL_SERVICE_NAME resolved by SDK: $OTEL_SERVICE_NAME"
    else
        # Local example fallback only. Real runtime should resolve via SDK metadata.
        LOCAL_DEFAULT_SERVICE_NAME="${AWX_LOCAL_CLIENT_SERVICE_NAME:-awx-builder-mcp-client}"
        export OTEL_SERVICE_NAME="$LOCAL_DEFAULT_SERVICE_NAME"
        export APP_NAME="${APP_NAME:-$LOCAL_DEFAULT_SERVICE_NAME}"
        export AWX_OTEL_SERVICE_NAME_OVERRIDE="${AWX_OTEL_SERVICE_NAME_OVERRIDE:-1}"
        echo "[Client] OTEL_SERVICE_NAME fallback for local example: $OTEL_SERVICE_NAME"
    fi
fi

if [ "${AWX_SMOKE:-0}" != "1" ]; then
    BUILT_OTEL_RESOURCE_ATTRIBUTES=$(
        $UV_BIN run --no-sync python - <<'PY'
import os

try:
    from awx.observability.instrumentation.resource_attributes import (
        build_resource_attributes,
    )
except Exception:
    raise


def _parse_resource_attributes(raw: str) -> dict[str, str]:
    out: dict[str, str] = {}
    if not raw:
        return out
    for part in raw.split(","):
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key:
            out[key] = value
    return out


def _encode_resource_attributes(attrs: dict[str, str]) -> str:
    def _sanitize_value(value: str) -> str:
        text = str(value).strip()
        if "," not in text:
            return text
        # OTEL_RESOURCE_ATTRIBUTES parser splits on commas and does not safely
        # preserve list-like payloads. Convert JSON-array style values into a
        # comma-free representation so startup never breaks.
        try:
            parsed = __import__("json").loads(text)
        except Exception:
            return ""
        if isinstance(parsed, list):
            return "|".join(str(item) for item in parsed)
        return ""

    encoded: list[str] = []
    for key, value in attrs.items():
        key_text = str(key).strip()
        if not key_text or "," in key_text or "=" in key_text:
            continue
        safe = _sanitize_value(str(value))
        if not safe:
            continue
        encoded.append(f"{key_text}={safe}")
    return ",".join(encoded)


existing = _parse_resource_attributes(os.getenv("OTEL_RESOURCE_ATTRIBUTES", ""))
for key, value in build_resource_attributes().items():
    if key in existing:
        continue
    text = str(value).strip()
    if text:
        existing[key] = text

print(_encode_resource_attributes(existing))
PY
    )
    if [ -n "$BUILT_OTEL_RESOURCE_ATTRIBUTES" ]; then
        export OTEL_RESOURCE_ATTRIBUTES="$BUILT_OTEL_RESOURCE_ATTRIBUTES"
        echo "[Client] OTEL_RESOURCE_ATTRIBUTES prepared: $OTEL_RESOURCE_ATTRIBUTES"
    fi
fi

$UV_BIN run --no-sync opentelemetry-instrument \
    uvicorn client:app --host $HOST --port $PORT
