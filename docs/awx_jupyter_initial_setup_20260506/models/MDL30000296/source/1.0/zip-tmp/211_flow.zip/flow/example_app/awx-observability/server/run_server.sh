#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8001}
UV_BIN=${3:-uv}

# ------------------------------------------------------------------
# Custom Package Install Path (Virtual Environment)
# ------------------------------------------------------------------
# Define CUSTOM_VENV_PATH environment variable to override location
# Example: export CUSTOM_VENV_PATH="/project/work/temp/venv"
# Default to /tmp/venv if not set
if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

export UV_CACHE_DIR="${UV_CACHE_DIR:-/tmp/uv-cache}"

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Server] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"

    # Initialize venv if missing
    if [ ! -d "$CUSTOM_VENV_PATH" ]; then
        echo "Creating new virtual environment..."
        $UV_BIN venv "$CUSTOM_VENV_PATH"
    fi
fi

echo "[Server] Starting MCP Server on $HOST:$PORT..."
$UV_BIN sync --no-install-project --inexact

load_env_defaults() {
    local env_file="$1"
    while IFS= read -r line || [ -n "$line" ]; do
        line="${line#"${line%%[![:space:]]*}"}"
        case "$line" in
            ""|\#*) continue ;;
        esac
        if [[ ! "$line" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
            continue
        fi
        local key="${line%%=*}"
        local value="${line#*=}"
        if [ -z "${!key+x}" ]; then
            export "$key=$value"
        fi
    done < "$env_file"
}

if [ -f .env ]; then
    set -a
    . ./.env
    set +a
fi

if [ -f .env.example ]; then
    load_env_defaults ./.env.example
fi

if [ -n "$MLDL_INFER_ENV_ID" ] && [ -z "$OTEL_SERVICE_NAME" ]; then
    export OTEL_SERVICE_NAME="$MLDL_INFER_ENV_ID"
fi

$UV_BIN run --no-sync opentelemetry-instrument \
    uvicorn server:app --host $HOST --port $PORT
