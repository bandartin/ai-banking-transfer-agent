"""
awx-observability Telemetry Example

Demonstrates how to use OpenTelemetry tracing with the awx.observability.telemetry module.
"""

from awx.observability.telemetry import get_tracer
from opentelemetry import trace

def main():
    print("=== AWX Observability - Telemetry Example ===\n")
    
    # Get the configured tracer
    tracer = get_tracer()
    
    # Example 1: Simple span
    print("1. Creating a simple trace span...")
    with tracer.start_as_current_span("data-processing") as span:
        span.set_attribute("operation", "data_load")
        span.set_attribute("rows", 1000)
        
        # Simulate some work
        process_data()
        
        print("✓ Span 'data-processing' created")

    # Example 2: Nested spans
    print("\n2. Creating nested spans...")
    with tracer.start_as_current_span("llm-request") as parent_span:
        parent_span.set_attribute("model", "gpt-4")
        parent_span.set_attribute("service_id", 10161)
        
        # Child span for prompt preparation
        with tracer.start_as_current_span("prepare-prompt") as child_span:
            child_span.set_attribute("prompt_length", 150)
            prepare_prompt()
            print("  ✓ Child span 'prepare-prompt' created")
        
        # Child span for API call
        with tracer.start_as_current_span("api-call") as child_span:
            child_span.set_attribute("endpoint", "https://api.openai.com/v1/chat/completions")
            call_llm_api()
            print("  ✓ Child span 'api-call' created")
        
        print("✓ Parent span 'llm-request' completed")

    # Example 3: Adding events to spans
    print("\n3. Adding events to a span...")
    with tracer.start_as_current_span("training-job") as span:
        span.set_attribute("job_id", "job-12345")
        
        span.add_event("Training started")
        train_model()
        
        span.add_event("Validation started")
        validate_model()
        
        span.add_event("Training completed", {
            "accuracy": 0.95,
            "loss": 0.05
        })
        
        print("✓ Span with events created")


def process_data():
    """Simulates data processing"""
    pass

def prepare_prompt():
    """Simulates prompt preparation"""
    pass

def call_llm_api():
    """Simulates LLM API call"""
    pass

def train_model():
    """Simulates model training"""
    pass

def validate_model():
    """Simulates model validation"""
    pass


if __name__ == "__main__":
    main()
