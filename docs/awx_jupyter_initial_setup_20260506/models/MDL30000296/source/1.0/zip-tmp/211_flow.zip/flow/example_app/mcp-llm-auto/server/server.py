import logging
import os
from dotenv import load_dotenv
from fastmcp import FastMCP

# ===================================================
# OpenTelemetry MCP 자동 계측
# ===================================================
# opentelemetry-instrumentation-mcp 패키지가 설치되어 있으면
# opentelemetry-instrument CLI가 자동으로 계측합니다.
# 명시적으로 McpInstrumentor().instrument()를 호출할 필요가 없습니다.
# (LangChain의 opentelemetry-instrumentation-langchain과 동일한 방식)

# ===================================================
# 환경 변수 로드
# ===================================================
load_dotenv()

# ===================================================
# 로깅 설정
# ===================================================
# stdio transport의 경우, 로그는 stderr로 출력하여
# MCP 프로토콜(stdout)과 충돌하지 않도록 합니다.
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]  # 기본적으로 stderr로 출력
)
logger = logging.getLogger("mcp-fast-server")

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# ===================================================
# FastAPI 및 FastMCP 설정
# ===================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI lifespan 이벤트
    OpenTelemetry 진단 로그 출력 (선택사항)
    """
    # opentelemetry-instrumentation-mcp가 자동으로 계측하므로
    # 수동으로 span을 생성할 필요가 없습니다.
    logger.info("=== MCP Server Starting ===")
    logger.info(f"SERVICE_NAME: {os.environ.get('OTEL_SERVICE_NAME')}")
    logger.info(f"ENDPOINT: {os.environ.get('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT')}")
    logger.info(f"PROTOCOL: {os.environ.get('OTEL_EXPORTER_OTLP_PROTOCOL', 'grpc (default)')}")
    logger.info("MCP Streamable HTTP endpoint will be available at: /mcp/")
    logger.info("Server is ready to accept connections")
    logger.info("=================================")
    async with mcp_app.lifespan(app):
        yield
    logger.info("=== MCP Server Shutting Down ===")

# FastMCP 및 FastAPI 설정
service_name = os.getenv("OTEL_SERVICE_NAME", "INF2026010223")
mcp = FastMCP(service_name)
app = FastAPI(
    title="MCP Fast Server (Auto Instrumentation)",
    description="MCP Server with OpenTelemetry Auto Instrumentation",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",  # Swagger UI: http://localhost:8001/docs
    redoc_url="/redoc",  # ReDoc: http://localhost:8001/redoc
    openapi_url="/openapi.json"  # OpenAPI Schema: http://localhost:8001/openapi.json
)

# CORS for browser-based MCP clients (e.g., MCP Inspector Direct mode).
# Comma-separated origins in CORS_ALLOW_ORIGINS, or "*" to allow all.
cors_origins_raw = os.getenv("CORS_ALLOW_ORIGINS", "*").strip()
if cors_origins_raw == "*" or cors_origins_raw == "":
    cors_allow_origins = ["*"]
else:
    cors_allow_origins = [origin.strip() for origin in cors_origins_raw.split(",") if origin.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_allow_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["mcp-session-id", "x-trace-id"],
)

# ===================================================
# Trace ID 응답 헤더 추가 미들웨어
# ===================================================
from opentelemetry import trace
from fastapi import Request

@app.middleware("http")
async def add_trace_id_header(request: Request, call_next):
    response = await call_next(request)
    
    # 현재 Span Context에서 Trace ID 가져오기
    span = trace.get_current_span()
    if span:
        span_context = span.get_span_context()
        if span_context.is_valid:
            trace_id = format(span_context.trace_id, "032x")
            response.headers["X-Trace-ID"] = trace_id
            
    return response

# FastMCP 앱을 /mcp 경로로 마운트 (Streamable HTTP transport)
logger.info(f"Initializing FastMCP with service_name: {service_name}")
mcp_app = mcp.http_app(path="/")
app.mount("/mcp", mcp_app)
logger.info("FastMCP mounted at /mcp/")

# ===================================================
# 루트 및 Health check 엔드포인트
# ===================================================
@app.get("/")
async def root():
    """루트 엔드포인트 - 서버 상태 확인"""
    return {
        "message": "MCP Fast Server with OpenTelemetry Auto Instrumentation",
        "service_name": service_name,
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "mcp": "/mcp/"
        },
        "note": "Trace는 opentelemetry-instrumentation-mcp에 의해 자동으로 생성되고 전송됩니다."
    }

@app.get("/health")
async def health_check():
    """
    서버 상태 확인 (Kubernetes liveness/readiness probe용)
    이 엔드포인트는 서버가 완전히 시작된 후 즉시 응답합니다.
    """
    return {
        "status": "healthy",
        "service_name": service_name,
        "ready": True,
        "note": "Trace는 opentelemetry-instrumentation-mcp에 의해 자동으로 생성되고 전송됩니다."
    }

# ===================================================
# MCP Tool 정의
# ===================================================
# opentelemetry-instrumentation-mcp가 자동으로
# tool 호출을 추적합니다. 수동으로 span을 생성할 필요가 없습니다.
@mcp.tool()
def add(a: int, b: int) -> int:
    """
    두 숫자를 더합니다.
    
    Args:
        a: 첫 번째 숫자
        b: 두 번째 숫자
    
    Returns:
        두 숫자의 합
    
    Note:
        opentelemetry-instrumentation-mcp가 자동으로 이 tool 호출을 추적합니다.
        수동으로 span을 생성하거나 수정할 필요가 없습니다.
    """
    logger.info(f"FastMCP calculating {a} + {b}")
    return a + b


@mcp.tool()
def subtract(a: int, b: int) -> int:
    """
    두 숫자를 뺍니다.

    Args:
        a: 첫 번째 숫자
        b: 두 번째 숫자

    Returns:
        a - b
    """
    logger.info(f"FastMCP calculating {a} - {b}")
    return a - b


@mcp.tool()
def multiply(a: int, b: int) -> int:
    """
    두 숫자를 곱합니다.

    Args:
        a: 첫 번째 숫자
        b: 두 번째 숫자

    Returns:
        a * b
    """
    logger.info(f"FastMCP calculating {a} * {b}")
    return a * b


@mcp.tool()
def divide(a: int, b: int) -> float:
    """
    두 숫자를 나눕니다.

    Args:
        a: 첫 번째 숫자
        b: 두 번째 숫자

    Returns:
        a / b

    Raises:
        ValueError: b가 0인 경우
    """
    if b == 0:
        raise ValueError("0으로 나눌 수 없습니다")
    logger.info(f"FastMCP calculating {a} / {b}")
    return a / b

# ===================================================
# 서버 실행
# ===================================================
# opentelemetry-instrument를 사용하여 실행하면
# 자동으로 계측됩니다.
if __name__ == "__main__":
    # stdio transport로 실행하려면:
    # mcp.run()
    
    # Streamable HTTP transport로 실행하려면 (FastAPI와 함께):
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
