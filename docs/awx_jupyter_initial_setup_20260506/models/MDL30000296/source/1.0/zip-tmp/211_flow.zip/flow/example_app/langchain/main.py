import argparse
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.langchain import LangchainInstrumentor
from opentelemetry.instrumentation.openai import OpenAIInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from router import router

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# OpenTelemetry 로깅 레벨 조정
logging.getLogger('opentelemetry').setLevel(logging.WARNING)


def _configure_trace_provider() -> None:
    current = trace.get_tracer_provider()
    if isinstance(current, TracerProvider):
        return
    service_name = os.getenv("OTEL_SERVICE_NAME", "langchain-service")
    provider = TracerProvider(resource=Resource.create({"service.name": service_name}))
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
    trace.set_tracer_provider(provider)


def _auto_instrument(app: FastAPI) -> None:
    # Standard OTel auto instrumentation without opentelemetry-instrument CLI
    fastapi_inst = FastAPIInstrumentor()
    if not fastapi_inst.is_instrumented_by_opentelemetry:
        fastapi_inst.instrument_app(app)

    langchain_inst = LangchainInstrumentor()
    if not langchain_inst.is_instrumented_by_opentelemetry:
        langchain_inst.instrument()

    openai_inst = OpenAIInstrumentor()
    if not openai_inst.is_instrumented_by_opentelemetry:
        openai_inst.instrument()

    httpx_inst = HTTPXClientInstrumentor()
    if not httpx_inst.is_instrumented_by_opentelemetry:
        httpx_inst.instrument()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 시작 시 테스트 span을 생성하여 exporter 체인 검증
    try:
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span("startup_connection_test") as span:
            span.set_attribute("service.startup", "true")
            logger.info("OTEL Startup Test Span Emitted")
            logger.info(f"OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: {os.environ.get('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT')}")
            logger.info(f"OTEL_SERVICE_NAME: {os.environ.get('OTEL_SERVICE_NAME')}")
    except Exception as e:
        logger.error(f"Failed to emit startup span: {e}")
    yield

app = FastAPI(title="LangChain with OpenTelemetry", lifespan=lifespan)
_configure_trace_provider()
_auto_instrument(app)

# 라우터 등록
app.include_router(router, prefix="/langchain", tags=["LangChain"])

@app.get("/")
async def root():
    return {"message": "LangChain API Server with OpenTelemetry"}


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8000")))
    parser.add_argument("--root-path", default=os.getenv("ROOT_PATH", ""))
    return parser.parse_args()


if __name__ == "__main__":
    import uvicorn

    args = _parse_args()
    uvicorn.run(app, host=args.host, port=args.port, root_path=args.root_path)
