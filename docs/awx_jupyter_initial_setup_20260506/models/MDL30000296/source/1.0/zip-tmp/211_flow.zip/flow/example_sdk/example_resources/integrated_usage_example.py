"""
AWX SDK 사용 예제

이 예제는 3개의 새로운 패키지를 사용하는 방법을 보여줍니다:
- awx-core
- awx-resources
- awx-observability
"""

# ============================================
# 1. awx-resources 사용 예제
# ============================================

from awx.resources import Credential, ExternalResource, Prompt

# Credential 조회 (개발 환경에서는 메타데이터 저장을 위해 provider_alias, service_type_name 필수)
cred_client = Credential()
credentials = cred_client.get(
    service_id=1,
    provider_alias="OpenAI",
    service_type_name="LLM"
)
print(f"첫 번째 Credential: {credentials[0]}")

# External Resource 조회
ext_res_client = ExternalResource()
resources = ext_res_client.get(
    provider_alias="OpenAI",
    solution_id="GENTEXT",
    service_type_name="LLM"
)
print(f"External Resources: {resources}")

# Prompt 조회
prompt_client = Prompt()
prompts = prompt_client.list()
print(f"Prompts: {prompts}")


# ============================================
# 2. awx-observability 사용 예제
# ============================================

from awx.observability import Metering, LLMLog, LogInput
import datetime

# Metering (Credential Log)
metering = Metering()
input_output_texts = [
    {
        "input_text": "AI 모델에게 질문할 내용입니다.",
        "output_text": "AI 모델이 답변한 내용입니다."
    }
]
credential = {
    "serviceId": "1",
    "credentialId": "1"
}
metering_response = metering.collect(
    input_output_texts=input_output_texts,
    model_name="gpt-4",
    credential=credential,
    model_type="LLM",
    platform_code="AWS"
)
print(f"Metering Response: {metering_response}")

# LLM Log
llm_log = LLMLog()
current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
log_input = LogInput(
    start_time=current_time,
    finish_time=current_time,
    project_id="PJT_ID",
    service_id="SVC_ID",
    input_tokens=100,
    output_tokens=50
)
llm_log.log(log_input)
print("LLM Log 전송 완료")


# ============================================
# 3. Telemetry (Tracer) 사용 예제
# ============================================

from awx.observability import Tracer, MldlTracer

# Tracer 사용 (기본 OpenTelemetry 기반)
tracer = Tracer()
with tracer.start_span("my_operation") as span:
    # 작업 수행
    span.set_attribute("key", "value")
    print("Tracing 작업 수행 중...")

# MLDL Tracer 사용
mldl_tracer = MldlTracer(
    project_id="PJT_ID",
    service_id="SVC_ID"
)
with mldl_tracer.start_span("mldl_operation") as span:
    print("MLDL Tracer 작업 수행 중...")

print("\\n✅ 모든 SDK 기능 테스트 완료!")
