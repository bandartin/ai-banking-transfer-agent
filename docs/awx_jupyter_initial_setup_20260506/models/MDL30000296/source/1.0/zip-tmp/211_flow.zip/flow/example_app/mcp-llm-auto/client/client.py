import os
import logging
from dotenv import load_dotenv
from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport

# ===================================================
# OpenTelemetry MCP 자동 계측
# ===================================================
# opentelemetry-instrumentation-mcp 패키지가 설치되어 있으면
# opentelemetry-instrument CLI가 자동으로 계측합니다.
# 명시적으로 McpInstrumentor().instrument()를 호출할 필요가 없습니다.
# (LangChain의 opentelemetry-instrumentation-langchain과 동일한 방식)

# ===================================================
# 환경 변수 로드
# ===================================================
load_dotenv()

# ===================================================
# 로깅 설정
# ===================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("mcp-fast-client")

# ===================================================
# OpenTelemetry Custom Metrics
# ===================================================
from opentelemetry import metrics
from opentelemetry.exporter.prometheus import PrometheusMetricReader
from opentelemetry.sdk.metrics import MeterProvider
from prometheus_client import REGISTRY, generate_latest

# Prometheus Metric Reader 설정
prometheus_reader = PrometheusMetricReader()
meter_provider = MeterProvider(metric_readers=[prometheus_reader])
metrics.set_meter_provider(meter_provider)

meter = metrics.get_meter("mcp-client-auto")

# 1. Client Metrics
token_usage_counter = meter.create_counter(
    "gen_ai.client.token.usage",
    unit="{token}",
    description="Tokens used by the LLM client"
)

operation_duration_histogram = meter.create_histogram(
    "gen_ai.client.operation.duration",
    unit="s",
    description="LLM client operation duration"
)

# 2. Server Metrics (Streaming) - for future implementation
ttft_histogram = meter.create_histogram(
    "gen_ai.server.time_to_first_token",
    unit="s",
    description="Time to first token"
)

tpot_histogram = meter.create_histogram(
    "gen_ai.server.time_per_output_token",
    unit="s",
    description="Time per output token"
)

from fastapi import FastAPI
from contextlib import asynccontextmanager
import uvicorn
from pydantic import BaseModel, Field
from typing import Optional
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
import time

# ===================================================
# FastAPI App 설정
# ===================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI lifespan 이벤트
    OpenTelemetry 진단 로그 출력
    """
    # opentelemetry-instrumentation-mcp가 자동으로 계측하므로
    # 수동으로 span을 생성할 필요가 없습니다.
    logger.info("=== MCP Client Starting ===")
    service_name = os.getenv("OTEL_SERVICE_NAME", "INF2026010222")
    mcp_server_url = os.getenv("MCP_SERVER_URL", "http://localhost:8001/mcp/")
    logger.info(f"SERVICE_NAME: {service_name}")
    logger.info(f"MCP_SERVER_URL: {mcp_server_url}")
    logger.info(f"OTEL_ENDPOINT: {os.environ.get('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT')}")
    logger.info(f"OTEL_PROTOCOL: {os.environ.get('OTEL_EXPORTER_OTLP_PROTOCOL', 'grpc (default)')}")
    logger.info("Server is ready to accept connections")
    logger.info("=================================")
    yield
    logger.info("=== MCP Client Shutting Down ===")

app = FastAPI(
    title="MCP Client API (Auto Instrumentation)",
    description="MCP Client with OpenTelemetry Auto Instrumentation",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",  # Swagger UI: http://localhost:8000/docs
    redoc_url="/redoc",  # ReDoc: http://localhost:8000/redoc
    openapi_url="/openapi.json"  # OpenAPI Schema: http://localhost:8000/openapi.json
)

# ===================================================
# Trace ID 응답 헤더 추가 미들웨어
# ===================================================
from opentelemetry import trace
from fastapi import Request

@app.middleware("http")
async def add_trace_id_header(request: Request, call_next):
    response = await call_next(request)
    
    # 현재 Span Context에서 Trace ID 가져오기
    span = trace.get_current_span()
    if span:
        span_context = span.get_span_context()
        if span_context.is_valid:
            trace_id = format(span_context.trace_id, "032x")
            response.headers["X-Trace-ID"] = trace_id
            
    return response

# ===================================================
# MCP Client 엔드포인트
# ===================================================
# opentelemetry-instrumentation-mcp가 자동으로
# MCP Client의 모든 호출을 추적합니다.
# 수동으로 span을 생성할 필요가 없습니다.
@app.get("/add")
async def add_numbers(a: int = 10, b: int = 20):
    """
    MCP Server의 add tool을 호출하는 엔드포인트
    
    Args:
        a: 첫 번째 숫자
        b: 두 번째 숫자
    
    Returns:
        MCP Server의 응답
    """
    # 서비스 이름
    service_name = os.getenv("OTEL_SERVICE_NAME", "INF2026010222")
    # MCP Server Streamable HTTP URL
    mcp_url = os.getenv("MCP_SERVER_URL", "http://localhost:8001/mcp/")
    
    logger.info(f"[{service_name}] Requesting add({a}, {b}) from {mcp_url}")

    # Streamable HTTP Transport
    transport = StreamableHttpTransport(url=mcp_url)
    
    try:
        logger.info(f"Connecting to MCP server at {mcp_url}...")
        async with Client(transport) as client:
            logger.info("Connected to MCP server, calling tool 'add'...")
            # MCP Server의 tool 호출
            # opentelemetry-instrumentation-mcp가 자동으로 추적합니다.
            # trace context는 자동으로 전파됩니다 (W3C Trace Context)
            # 수동으로 span을 생성하거나 수정할 필요가 없습니다.
            result = await client.call_tool("add", {"a": a, "b": b})
            
            logger.info(f"Tool call successful. Result: {result.data}")
            
            # 순수하게 자동 계측만으로 동작
            # trace는 자동으로 생성되고 전송됩니다.
            return {
                "result": result.data,
                "server": mcp_url,
                "service_name": service_name,
                "note": "Trace는 opentelemetry-instrumentation-mcp에 의해 자동으로 생성되고 전송됩니다."
            }
    except Exception as e:
        logger.error(f"Error calling MCP server: {e}", exc_info=True)
        return {
            "error": str(e),
            "server": mcp_url,
            "service_name": service_name,
            "note": "MCP 서버 연결에 실패했습니다. 서버가 실행 중인지 확인하세요."
        }

# ===================================================
# 루트 및 Health check 엔드포인트
# ===================================================
@app.get("/")
async def root():
    """루트 엔드포인트 - 서버 상태 확인"""
    service_name = os.getenv("OTEL_SERVICE_NAME", "INF2026010222")
    mcp_server_url = os.getenv("MCP_SERVER_URL", "http://localhost:8001/mcp/")
    return {
        "message": "MCP Client API with OpenTelemetry Auto Instrumentation",
        "service_name": service_name,
        "mcp_server_url": mcp_server_url,
        "endpoints": {
            "add": "/add?a=10&b=20",
            "chat": "/chat",
            "docs": "/docs",
            "health": "/health",
            "metrics": "/metrics"
        },
        "note": "Trace는 opentelemetry-instrumentation-mcp에 의해 자동으로 생성되고 전송됩니다."
    }

class ChatRequest(BaseModel):
    message: str
    topic: Optional[str] = "일반"
    # Essential Attributes for OTel
    system: Optional[str] = "openai"
    request_model: Optional[str] = "gpt-4o"
    # AWX Specific Context
    credential_id: Optional[str] = Field(default="8", alias="awx.credential.id")
    provider_id: Optional[str] = Field(default="1", alias="awx.ext.provider.id")
    service_id: Optional[str] = Field(default="29", alias="awx.ext.service.id")
    service_type: Optional[str] = Field(default="SERVICE_TYPE_01", alias="awx.ext.service.type")

    class Config:
        populate_by_name = True

@app.post("/chat")
async def chat(request: ChatRequest):
    """
    기본 LLM 채팅 엔드포인트
    OpenTelemetry가 자동으로 LLM 호출을 추적하며, Custom Metrics와 Attributes를 추가합니다.
    """
    # 1. Start Trace Span Customization
    current_span = trace.get_current_span()
    
    # 공통 Attributes 준비
    attributes = {
        "gen_ai.system": request.system,
        "gen_ai.request.model": request.request_model,
        "gen_ai.operation.name": "chat",
        "awx.credential.id": request.credential_id,
        "awx.ext.provider.id": request.provider_id,
        "awx.ext.service.id": request.service_id,
        "awx.ext.service.type": request.service_type,
    }

    # 현재 Span에 Attributes 추가
    if current_span and current_span.get_span_context().is_valid:
         for key, value in attributes.items():
            if value:
                current_span.set_attribute(key, value)

    start_time = time.time()
    
    try:
        # 환경 변수에서 OPENAI_API_KEY 설정 필요
        llm = ChatOpenAI(model=request.request_model, temperature=0.7)
        
        # Define MCP Tool
        # We define it inside to close over the client connection nicely or we can use a fresh connection
        mcp_url = os.getenv("MCP_SERVER_URL", "http://localhost:8001/mcp/")
        
        # Helper function to call MCP server
        async def call_mcp_add(a: int, b: int) -> int:
            """Helper to call MCP server add tool"""
            transport = StreamableHttpTransport(url=mcp_url)
            async with Client(transport) as mcp_client:
                result = await mcp_client.call_tool("add", {"a": a, "b": b})
                return result.data
        
        # Tool definition using LangChain @tool decorator
        @tool
        async def add(a: int, b: int) -> int:
            """Add two numbers. Use this tool for addition calculations."""
            return await call_mcp_add(a, b)

        tools = [add]
        
        # Create ReAct Agent
        agent_executor = create_react_agent(llm, tools)
        
        # Agent 실행
        # Use invoke to run the agent
        response_data = await agent_executor.ainvoke({"messages": [
            SystemMessage(content="You are a helpful assistant. Use the available tools for calculations."),
            HumanMessage(content=request.message)
        ]})
        
        # Extract the final response message
        response_message = response_data["messages"][-1]
        content = response_message.content
        
        # Mocking response object for metrics (simplification)
        # In a real agent scenario, token usage is aggregated across multiple calls.
        # This part simplifies extracting usage from the *last* LLM call if available, 
        # or we might need to sum up usage if available in the state.
        # For now, we will try to extract usage from the response_message if it has additional_kwargs
        
        # response_message typcially is AIMessage.
        response_metadata = response_message.response_metadata if hasattr(response_message, "response_metadata") else {}
        
        duration = time.time() - start_time
        
        # 2. Record Client Metrics
        
        # Duration Metric
        operation_duration_histogram.record(duration, attributes)
        
        # Token Usage Metric
        if response_metadata and "token_usage" in response_metadata:
            usage = response_metadata["token_usage"]
            # Input Tokens
            token_usage_counter.add(
                usage.get("prompt_tokens", 0),
                {**attributes, "gen_ai.token.type": "input"}
            )
            # Output Tokens
            token_usage_counter.add(
                usage.get("completion_tokens", 0),
                {**attributes, "gen_ai.token.type": "output"}
            )
        
        # Response Attributes to Span
        if current_span and current_span.get_span_context().is_valid:
            current_span.set_attribute("gen_ai.response.model", response_metadata.get("model_name", request.request_model))
            if response_metadata.get("finish_reason"):
                current_span.set_attribute("gen_ai.response.finish_reason", response_metadata.get("finish_reason"))
            if hasattr(response_message, "id") and response_message.id:
                 current_span.set_attribute("gen_ai.response.id", response_message.id)

        return {
            "response": content,
            "metadata": response_metadata,
            "trace_id": format(current_span.get_span_context().trace_id, "032x") if current_span else None
        }

    except Exception as e:
        logger.error(f"Error calling LLM: {e}", exc_info=True)
        if current_span and current_span.get_span_context().is_valid:
            current_span.record_exception(e)
            current_span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
        return {"error": str(e)}

@app.get("/health")
async def health_check():
    """
    서버 상태 확인 (Kubernetes liveness/readiness probe용)
    이 엔드포인트는 서버가 완전히 시작된 후 즉시 응답합니다.
    """
    service_name = os.getenv("OTEL_SERVICE_NAME", "INF2026010222")
    mcp_server_url = os.getenv("MCP_SERVER_URL", "http://localhost:8001/mcp/")
    return {
        "status": "healthy",
        "service_name": service_name,
        "mcp_server_url": mcp_server_url,
        "ready": True,
        "note": "Trace는 opentelemetry-instrumentation-mcp에 의해 자동으로 생성되고 전송됩니다."
    }

@app.get("/metrics")
async def metrics():
    """
    Prometheus 메트릭 엔드포인트
    OpenTelemetry 메트릭을 Prometheus 형식으로 노출합니다.
    """
    from fastapi.responses import Response
    
    # Prometheus 메트릭을 텍스트 형식으로 생성
    metrics_output = generate_latest(REGISTRY)
    return Response(content=metrics_output, media_type="text/plain; charset=utf-8")


# ===================================================
# 서버 실행
# ===================================================
if __name__ == "__main__":
    # opentelemetry-instrument를 사용하여 실행하면
    # 자동으로 계측됩니다.
    uvicorn.run(app, host="0.0.0.0", port=8000)
