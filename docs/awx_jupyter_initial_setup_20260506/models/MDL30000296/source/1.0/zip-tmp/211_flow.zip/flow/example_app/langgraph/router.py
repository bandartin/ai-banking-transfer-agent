import operator
import logging
import importlib.util
from typing import Optional, List, Dict, Any, TypedDict, Annotated

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

# ===================================================
# LangGraph imports
# ===================================================
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import create_react_agent

# ===================================================
# LangChain imports
# ===================================================
# 주석: LLM은 사용자 환경에 맞게 변경 가능 (OpenAI, Anthropic 등)
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, BaseMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import Tool

logger = logging.getLogger(__name__)

# ddgs는 선택적 의존성 (예제용)
DDGS_AVAILABLE = importlib.util.find_spec("ddgs") is not None
if not DDGS_AVAILABLE:
    logger.warning("ddgs 모듈을 사용할 수 없습니다. /chat/agent 엔드포인트에서 검색 기능이 비활성화됩니다.")

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    topic: Optional[str] = "일반"

# ===================================================
# OpenTelemetry 자동 계측
# ===================================================
# opentelemetry-instrumentation-langchain이 자동으로
# LangGraph의 모든 실행을 추적합니다.
# LangGraph는 LangChain 위에 구축되므로 추가 코드 수정이 필요 없습니다.

@router.post("/chat/basic")
async def basic_chat(request: ChatRequest):
    """
    기본 LangGraph 채팅 예제
    OpenTelemetry가 자동으로 LLM 호출을 추적합니다.
    """
    try:
        # 주석: 모델명과 API 키는 환경 변수 또는 .env 파일에서 설정
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)
        messages = [
            SystemMessage(content="당신은 도움이 되는 AI 어시스턴트입니다. (LangGraph Basic)"),
            HumanMessage(content=request.message)
        ]
        response = llm.invoke(messages)
        return {"response": response.content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/agent")
async def agent_chat(request: ChatRequest):
    """
    LangGraph ReAct Agent 예제
    Agent 실행과 Tool 호출이 자동으로 추적됩니다.
    """
    try:
        tools = []
        
        # ddgs가 사용 가능한 경우에만 검색 도구 추가
        if DDGS_AVAILABLE:
            def ddgs_search_func(query: str) -> str:
                try:
                    from ddgs import DDGS
                    with DDGS(verify=False) as ddgs:
                        results = list(ddgs.text(query, max_results=5))
                        return str(results)
                except Exception as e:
                    return f"Error: {e}"

            search_tool = Tool(
                name="duckduckgo_search",
                description="Search the web for information using DuckDuckGo",
                func=ddgs_search_func
            )
            tools.append(search_tool)
        else:
            # ddgs가 없는 경우 간단한 계산 도구 예제
            def calculator_func(expression: str) -> str:
                try:
                    # 간단한 계산 예제 (보안상 eval 사용은 권장하지 않지만 예제용)
                    result = eval(expression)
                    return str(result)
                except Exception as e:
                    return f"Error: {e}"
            
            calc_tool = Tool(
                name="calculator",
                description="Perform basic mathematical calculations",
                func=calculator_func
            )
            tools.append(calc_tool)
        
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
        # create_react_agent는 LangGraph의 prebuilt agent
        agent_executor = create_react_agent(llm, tools)
        
        messages = [
            SystemMessage(content="당신은 유용한 AI 어시스턴트입니다."),
            HumanMessage(content=request.message)
        ]
        result = agent_executor.invoke({"messages": messages})
        messages = result.get("messages", [])
        last_message = messages[-1] if messages else None
        return {"response": last_message.content if last_message else ""}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ===================================================
# Custom StateGraph Example
# ===================================================
class GraphState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    topic: str

def chatbot_node(state: GraphState):
    """
    커스텀 그래프 노드
    OpenTelemetry가 자동으로 이 노드의 실행을 추적합니다.
    """
    llm = ChatOpenAI(model="gpt-3.5-turbo")
    topic = state.get("topic", "일반")
    prompt = ChatPromptTemplate.from_messages([
        ("system", f"당신은 {topic} 전문가입니다."),
        ("human", "{input}")
    ])
    chain = prompt | llm
    last_user_message = state["messages"][-1]
    response = chain.invoke({"input": last_user_message.content})
    return {"messages": [response]}

# 그래프 구성
workflow = StateGraph(GraphState)
workflow.add_node("chatbot", chatbot_node)
workflow.set_entry_point("chatbot")
workflow.add_edge("chatbot", END)
graph_app = workflow.compile()

@router.post("/chat/custom-graph")
async def custom_graph_chat(request: ChatRequest):
    """
    커스텀 StateGraph 예제
    그래프 실행이 자동으로 추적됩니다.
    """
    try:
        inputs = {
            "messages": [HumanMessage(content=request.message)],
            "topic": request.topic
        }
        result = graph_app.invoke(inputs)
        messages = result.get("messages", [])
        return {"response": messages[-1].content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/error-test")
async def error_test_chat(request: ChatRequest):
    """
    에러 추적 테스트용 엔드포인트
    OpenTelemetry가 에러 정보를 자동으로 span에 기록하는지 확인
    """
    error_type = request.message.lower()
    try:
        if error_type == "invalid_api_key":
            llm = ChatOpenAI(model="gpt-3.5-turbo", openai_api_key="invalid-key-12345", temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        elif error_type == "invalid_model":
            llm = ChatOpenAI(model="gpt-invalid-model-name-999", temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        elif error_type == "timeout":
            llm = ChatOpenAI(model="gpt-3.5-turbo", timeout=0.001, temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        else:
            raise ValueError(f"LangGraph 테스트 에러: {error_type}")
    except Exception as e:
        logger.error(f"LangGraph 에러 발생 - type: {type(e).__name__}, message: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": type(e).__name__,
                "error_message": str(e),
                "note": "OpenTelemetry가 LangGraph 에러를 기록하는지 확인하세요"
            }
        )

@router.get("/")
async def root():
    return {"message": "LangGraph Router works!"}
