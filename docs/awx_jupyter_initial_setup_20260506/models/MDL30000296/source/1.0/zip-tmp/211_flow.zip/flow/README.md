# AWX Flow Examples

This directory contains example applications and SDK guides for AWX.

## Usage

The workflow is managed via `make` commands.

### 1. Initialize an App
Select an app and optional mode (default: `server`).

```bash
# Initialize Server (Default) - Positional Argument Supported
make init sampleapp
# Or explicit argument
make init app=mcp-llm-auto

# Initialize Client (Specific Mode)
make init mcp-llm-auto.client
```

This sets the context in `.app_env`. No files are copied.

### 2. Check Current App
To see which app is currently initialized:
```bash
make which
# Output:
# APP_NAME=sampleapp
# APP_MODE=server
```

### 3. Sync Dependencies
Install dependencies for the selected app.

```bash
make sync
```

### 3. Run Application
Run the initialized app/mode.

```bash
make run
```

---

## Metrics & Modes
- **Server Mode**: Runs the application backend (usually Port 8001).
- **Client Mode**: Runs the example client (usually Port 8000).

## Proxy Support (Swagger UI / Docs)
The platform automatically detects if you are running in a proxy environment (Code Server, JupyterHub) and configures the application to serve Swagger UI (`/docs`) correctly.

- **Auto-Detection**:
    - **VS Code**: Detects `VSCODE_PROXY_URI`.
    - **Jupyter**: Detects `JUPYTERHUB_SERVICE_PREFIX`.
- **Manual Configuration**:
    - You can manually override the proxy path by setting the directory:
      ```bash
      export ROOT_PATH="/proxy/8001"
      make run
      ```

## Available Apps

| App Name | Description | Modes |
|----------|-------------|-------|
| `sampleapp` | Basic FastAPI example | `server` |
| `mcp-simple-auto` | Minimal MCP server with OTel auto instrumentation (no LLM) | `server` |
| `mcp-llm-auto` | MCP-LLM Integrated Example | `server`, `client` |
| `awx-observability` | AWX Observability example | `server`, `client` |
| `filter-sdk-only` | Minimal filter SDK (guardrail) server example | `server` |
| `langchain` | LangChain Integration Example | `server` |
| `langgraph` | LangGraph Integration Example | `server` |

## MCP-LLM + Inspector Guide

For `mcp-llm-auto` server/client split setup and Inspector details:

- `example_app/mcp-llm-auto/README.md`

## Directory Structure
- `example_app/`: Application source codes.
- `example_sdk/`: SDK usage guides (not runnable via make run, reference only).
- `run-application.sh`: Main launcher script.
- `Makefile`: workflow orchestrator.

## Concurrent Execution
You can run multiple apps simultaneously by overriding arguments directly in the `make` command, bypassing the global `.app_env` context.

```bash
# Run 'awx-observability' on port 8002
make run app=awx-observability port=8002

# Run 'mcp-llm-auto' client on port 8003
make run app=mcp-llm-auto mode=client port=8003
```
