import socket
from datetime import datetime

from fastapi import HTTPException


def check_port_open(host, port, service_name="SERVICE"):
    """
    CHECK PORT AVAILABLE (LOCAL LLM)
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.2)

    try:
        result = sock.connect((host, int(port)))
        sock.close()

    except Exception as e:
        sock.close()
        raise HTTPException(
            status_code=503,
            detail=f"service '{service_name}' not available, target_url: {host}:{port}, error message: {e}",
        )


def get_callback_data(request, request_body, ic):
    """
    GET CALLBACK DATA
    """
    model_info = ic.get_model_info()
    if not model_info:
        model_info = {"AI_SERVICE_TEMP": "1.0"}
    model_id = list(model_info.keys())[0]

    callback_data = {
        "start_time": datetime.now(),
        "model_id": model_id,
        "model_ver": model_info[model_id],
        "request_header": {"content-type": request.headers.get("content-type")},
        "request_body": request_body,
        "client_ip": request.client.host,
        "api_url": request.url.path,
    }

    return callback_data
