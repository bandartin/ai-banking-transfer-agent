#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8001}
UV_BIN=${3:-uv}

# Resolve script location once and run relative to it.
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd "$SCRIPT_DIR"

if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Server] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    $UV_BIN venv --allow-existing "$CUSTOM_VENV_PATH"
fi

# Prefer local SDK sources when available.
SDK_ROOT=$(cd "$SCRIPT_DIR/../../../../../python-user-sdk" 2>/dev/null && pwd)
if [ -n "$SDK_ROOT" ]; then
    SDK_PATHS=(
        "$SDK_ROOT/awx_core/src"
        "$SDK_ROOT/awx_resources/src"
        "$SDK_ROOT/awx_observability/src"
    )
    LOCAL_SDK_PYTHONPATH=""
    for p in "${SDK_PATHS[@]}"; do
        if [ -d "$p" ]; then
            if [ -n "$LOCAL_SDK_PYTHONPATH" ]; then
                LOCAL_SDK_PYTHONPATH="${LOCAL_SDK_PYTHONPATH}:$p"
            else
                LOCAL_SDK_PYTHONPATH="$p"
            fi
        fi
    done
    if [ -n "$LOCAL_SDK_PYTHONPATH" ]; then
        if [ -n "$PYTHONPATH" ]; then
            export PYTHONPATH="${LOCAL_SDK_PYTHONPATH}:$PYTHONPATH"
        else
            export PYTHONPATH="$LOCAL_SDK_PYTHONPATH"
        fi
    fi
fi

echo "[Server] Starting filter-sdk-only app on $HOST:$PORT..."

if [ -f "$SCRIPT_DIR/.env" ]; then
    set -a
    . "$SCRIPT_DIR/.env"
    set +a
fi

if [ -z "$PIP_INDEX_URL" ] && [ -z "$PIP_EXTRA_INDEX_URL" ] && [ -z "$UV_LOCAL_PACKAGES" ]; then
    if python3 - <<'PY' >/dev/null 2>&1
import importlib
import sys

required = ("fastapi", "uvicorn", "awx.resources")
for name in required:
    try:
        importlib.import_module(name)
    except Exception:
        sys.exit(1)
sys.exit(0)
PY
    then
        echo "[Flow] Skipping uv sync (using system-installed packages)."
        SKIP_UV_SYNC=1
    fi
fi

if [ -z "$SKIP_UV_SYNC" ]; then
    $UV_BIN sync
fi

ARGS="python main.py --host $HOST --port $PORT"
if [ -n "$ROOT_PATH" ]; then
    ARGS="$ARGS --root-path $ROOT_PATH"
fi

if [ -n "$SKIP_UV_SYNC" ]; then
    if ! command -v opentelemetry-instrument >/dev/null 2>&1; then
        echo "[Flow] ERROR: opentelemetry-instrument not found."
        echo "[Flow] Install opentelemetry-distro in the runtime environment."
        exit 3
    fi
    opentelemetry-instrument $ARGS
elif [ -f "$SCRIPT_DIR/.env" ]; then
    $UV_BIN run --env-file "$SCRIPT_DIR/.env" opentelemetry-instrument $ARGS
else
    $UV_BIN run opentelemetry-instrument $ARGS
fi
