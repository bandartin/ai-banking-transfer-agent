#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8000}
UV_BIN=${3:-uv}
INSPECTOR_PID=""

load_env_defaults() {
    local env_file="$1"
    while IFS= read -r line || [ -n "$line" ]; do
        line="${line#"${line%%[![:space:]]*}"}"
        case "$line" in
            ""|\#*) continue ;;
        esac
        if [[ ! "$line" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
            continue
        fi
        local key="${line%%=*}"
        local value="${line#*=}"
        if [ -z "${!key+x}" ]; then
            export "$key=$value"
        fi
    done < "$env_file"
}

append_origin_if_missing() {
    local origin="$1"
    origin="${origin%/}"
    if [ -z "$origin" ]; then
        return
    fi
    case ",${AUTO_ALLOWED_ORIGINS}," in
        *,"$origin",*) ;;
        *)
            if [ -z "${AUTO_ALLOWED_ORIGINS}" ]; then
                AUTO_ALLOWED_ORIGINS="$origin"
            else
                AUTO_ALLOWED_ORIGINS="${AUTO_ALLOWED_ORIGINS},$origin"
            fi
            ;;
    esac
}

auto_configure_allowed_origins() {
    # Respect explicit ALLOWED_ORIGINS if already configured.
    if [ -n "${ALLOWED_ORIGINS:-}" ]; then
        echo "[Inspector] Using configured ALLOWED_ORIGINS: ${ALLOWED_ORIGINS}"
        return
    fi

    AUTO_ALLOWED_ORIGINS=""

    # Optional seed list (comma-separated).
    if [ -n "${MCP_INSPECTOR_ALLOWED_ORIGINS:-}" ]; then
        local seeded
        for seeded in ${MCP_INSPECTOR_ALLOWED_ORIGINS//,/ }; do
            append_origin_if_missing "$seeded"
        done
    fi

    # Local fallback origins from Inspector host/port.
    if [ "${INSPECTOR_HOST}" = "0.0.0.0" ] || [ -z "${INSPECTOR_HOST}" ]; then
        append_origin_if_missing "http://127.0.0.1:${INSPECTOR_PORT}"
        append_origin_if_missing "http://localhost:${INSPECTOR_PORT}"
    elif [ "${INSPECTOR_HOST}" = "::" ]; then
        append_origin_if_missing "http://[::1]:${INSPECTOR_PORT}"
    else
        append_origin_if_missing "http://${INSPECTOR_HOST}:${INSPECTOR_PORT}"
    fi

    # VS Code proxy URL usually contains the externally visible browser origin.
    if [ -n "${VSCODE_PROXY_URI:-}" ]; then
        local vscode_origin
        vscode_origin=$(echo "${VSCODE_PROXY_URI}" | sed -E 's#^(https?://[^/]+).*$#\1#')
        append_origin_if_missing "$vscode_origin"
    fi

    # Manual browser origin hint for random external ports.
    if [ -n "${MCP_INSPECTOR_BROWSER_ORIGIN:-}" ]; then
        append_origin_if_missing "${MCP_INSPECTOR_BROWSER_ORIGIN}"
    fi

    if [ -n "${AUTO_ALLOWED_ORIGINS}" ]; then
        export ALLOWED_ORIGINS="${AUTO_ALLOWED_ORIGINS}"
        echo "[Inspector] Auto-configured ALLOWED_ORIGINS: ${ALLOWED_ORIGINS}"
    fi
}

cleanup() {
    if [ -n "$INSPECTOR_PID" ] && kill -0 "$INSPECTOR_PID" 2>/dev/null; then
        echo "[Inspector] Stopping MCP Inspector (pid: $INSPECTOR_PID)"
        kill "$INSPECTOR_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT INT TERM

# ------------------------------------------------------------------
# Custom Package Install Path (Virtual Environment)
# ------------------------------------------------------------------
# Define CUSTOM_VENV_PATH environment variable to override location
# Example: export CUSTOM_VENV_PATH="/project/work/temp/venv"
# Default to /tmp/venv if not set
if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Server] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    
    # Initialize venv if missing
    if [ ! -d "$CUSTOM_VENV_PATH" ]; then
        echo "Creating new virtual environment..."
        $UV_BIN venv "$CUSTOM_VENV_PATH"
    fi
fi

# ------------------------------------------------------------------
# ENV FILE LOADING (server directory)
# ------------------------------------------------------------------
SERVER_ENV_FILE="server/.env"
SERVER_ENV_EXAMPLE_FILE="server/.env.example"

if [ -f "$SERVER_ENV_FILE" ]; then
    set -a
    . "$SERVER_ENV_FILE"
    set +a
fi

if [ -f "$SERVER_ENV_EXAMPLE_FILE" ]; then
    load_env_defaults "$SERVER_ENV_EXAMPLE_FILE"
fi

# Resolve inspector networking after env loading so .env/.env.example is honored
INSPECTOR_HOST=${MCP_INSPECTOR_HOST:-$HOST}
INSPECTOR_PORT=${MCP_INSPECTOR_PORT:-5000}
INSPECTOR_PROXY_PORT=${MCP_INSPECTOR_PROXY_PORT:-6277}
auto_configure_allowed_origins

# ------------------------------------------------------------------
# MCP INSPECTOR (OPTIONAL)
# ------------------------------------------------------------------
if [ "${MCP_INSPECTOR_ENABLED:-false}" = "true" ]; then
    if command -v mcp-inspector >/dev/null 2>&1; then
        echo "[Inspector] Starting MCP Inspector on ${INSPECTOR_HOST}:${INSPECTOR_PORT} (proxy: ${INSPECTOR_PROXY_PORT})"
        HOST="${INSPECTOR_HOST}" \
        CLIENT_PORT="${INSPECTOR_PORT}" \
        SERVER_PORT="${INSPECTOR_PROXY_PORT}" \
        MCP_PROXY_PORT="${INSPECTOR_PROXY_PORT}" \
        ALLOWED_ORIGINS="${ALLOWED_ORIGINS:-}" \
        DANGEROUSLY_OMIT_AUTH="${MCP_INSPECTOR_OMIT_AUTH:-true}" \
        MCP_AUTO_OPEN_ENABLED="${MCP_AUTO_OPEN_ENABLED:-false}" \
        mcp-inspector &
        INSPECTOR_PID=$!
        echo "[Inspector] MCP Inspector started (pid: $INSPECTOR_PID)"
    else
        echo "[Inspector] mcp-inspector command not found. Skip Inspector startup."
    fi
fi

echo "[Server] Starting App on $HOST:$PORT..."
cd server
bash run_server.sh "$HOST" "$PORT" "$UV_BIN"
