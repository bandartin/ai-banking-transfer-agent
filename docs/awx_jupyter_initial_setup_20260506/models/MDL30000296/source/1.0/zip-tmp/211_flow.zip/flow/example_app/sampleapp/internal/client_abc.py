from abc import ABC, abstractmethod
from typing import Any, Dict, Generator, Optional


class GeneratorClient(ABC):
    """Abstract base class for text generator clients."""

    @abstractmethod
    def generate(
        self,
        message: str,
        callback: Optional[Any] = None,
        callback_data: Optional[Dict] = None,
    ) -> Generator[str, None, None]:
        """
        Generate text responses based on input message.

        Args:
            message: User input/question
            callback: Callback for result tracking
            callback_data: Data for callback processing

        Returns:
            Generator yielding formatted response strings
        """
        pass
