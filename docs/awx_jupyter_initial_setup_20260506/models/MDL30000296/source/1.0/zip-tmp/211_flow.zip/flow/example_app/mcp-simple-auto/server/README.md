# MCP Simple Auto Server

Minimal MCP server example without any LLM dependency.

## Run (`make` workflow)

From `example_awx/flow`:

```bash
make init mcp-simple-auto
make run
```

Default bind: `0.0.0.0:8000`

## Endpoints (default)

- MCP Streamable HTTP: `/mcp`
- Health: `/health`
- Swagger: `/docs`

## Tools

- `add(a: float, b: float) -> float`
- `subtract(a: float, b: float) -> float`
- `multiply(a: float, b: float) -> float`
- `divide(a: float, b: float) -> float`

## OTel

`run_server.sh` starts with `opentelemetry-instrument`.
If `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` is not set, startup prints warning logs.
