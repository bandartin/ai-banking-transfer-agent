# LangChain + OpenTelemetry (Code-Based Instrumentation)

이 예제는 `opentelemetry-instrument` CLI 없이, 앱 코드에서 OTel 계측을 초기화합니다.

## 1. 설치

```bash
uv sync
```

## 2. 환경 변수

`.env.example`를 `.env`로 복사한 뒤 값을 설정합니다.

필수(예시):
- `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT`
- `OTEL_SERVICE_NAME=langchain-service`
- `OPENAI_API_KEY`

권장:
- `OTEL_EXPORTER_OTLP_PROTOCOL=grpc`
- `OTEL_EXPORTER_OTLP_INSECURE=true`

선택:
- `OTEL_METRICS_EXPORTER`, `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT`
- `OTEL_LOGS_EXPORTER`, `OTEL_EXPORTER_OTLP_LOGS_ENDPOINT`

## 3. 실행

```bash
bash run_app.sh
```

또는 직접 실행:

```bash
uv run --env-file .env python main.py --host 0.0.0.0 --port 8000
```

## 4. 테스트 호출

```bash
curl -X POST 'http://127.0.0.1:8000/langchain/chat/basic' \
  -H 'Content-Type: application/json' \
  -d '{"message":"안녕","topic":"일반"}'
```

```bash
curl -X POST 'http://127.0.0.1:8000/langchain/chat/prompt' \
  -H 'Content-Type: application/json' \
  -d '{"message":"RAG가 뭐야?","topic":"AI"}'
```

## 5. 계측 범위

`main.py`에서 아래 라이브러리를 코드 기반으로 instrument 합니다.
- FastAPI
- LangChain
- OpenAI
- HTTPX

따라서 라우터의 비즈니스 로직(`router.py`)은 별도 OTel 코드 없이 그대로 유지됩니다.
