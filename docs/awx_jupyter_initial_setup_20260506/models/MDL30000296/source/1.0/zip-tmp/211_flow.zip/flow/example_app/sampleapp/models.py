from pydantic import BaseModel, Field


class InputOrch(BaseModel):
    question: str = Field(examples=["한국의 수도는 어디에요?"])


class InputGeneral(BaseModel):
    data: str = Field(examples={"key": "value"})


# Stream response sample for API documentation
STREAM_RESPONSE_SAMPLE = """data: {"token": {"text": "some", "special":false}, "generated_text": null} 
data: {"token": {"text": "generated", "special":false}, "generated_text": null}
data: {"token": {"text": "text", "special":false}, "generated_text": null}
data: {"token": {"text": "[DONE]", "special":true}, "generated_text": "some generated text[DONE]"}
"""
