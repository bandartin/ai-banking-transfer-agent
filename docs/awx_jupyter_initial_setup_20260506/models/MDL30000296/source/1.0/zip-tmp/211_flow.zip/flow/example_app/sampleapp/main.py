import uvicorn

# Import from reorganized modules
from config import (
    HOST,
    LIMIT_CONCURRENCY,
    MLDL_SERVICE_CONTEXT_PATH_SIMULATION,
    PORT,
    TAGS_METADATA,
    WORKERS,
    SERVERS
)
from awx.observability import InferCollector
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import the dependency function placeholder
from routes import get_collector, router

"""
이 샘플 애플리케이션은 AWX SDK 사용을 위한 예제입니다.

### 애플리케이션 구조
- **main.py**: FastAPI 애플리케이션의 진입점으로, 서버 설정 및 라우터를 포함합니다.
- **routes.py**: API 엔드포인트를 정의하며, 의존성 주입을 통해 InferenceCollector를 사용합니다.
- **config.py**: 서버 설정(포트, 호스트 등) 및 메타데이터를 관리합니다.
- **utils**: 유틸리티 함수 및 공통 기능을 포함합니다.
- **static**: 웹에 접근이 불가능한 경우를 위해 swagger ui 페이지의 리소스들을 직접 호스팅하기 위한 정적 파일(예: HTML, CSS, JS)을 제공하는 디렉토리입니다.
- **internal**: 사용할 예제 클라이언트입니다. 두 가지 종류가 있습니다. client_example.py는 정해진 문장을 생성하는 기본적인 예제 클라이언트이며, client_langchain.py는 LangChain을 사용한 예제 클라이언트입니다. 기본적으로 client_example.py가 사용됩니다. client_langchain.py를 사용하고 싶다면, routes.py 의 get_generator_client() 함수를 수정하여 사용하시면 됩니다.

### 주의사항
- 이 애플리케이션은 학습 및 데모 목적으로 설계되었습니다. 실제 운영 환경에서는 추가적인 보안 및 최적화가 필요할 수 있습니다.
- `main.py`에서 서버 설정(포트, 호스트 등)을 변경하여 로컬 환경에 맞게 조정할 수 있습니다.
- 실제 실행은 run-application.sh 스크립트를 통해서도 가능합니다. 이 때 어플리케이션 설정에 gunicorn_config.py 파일을 사용할 수 있습니다.
"""

# Initialize FastAPI app
app = FastAPI(
    root_path=MLDL_SERVICE_CONTEXT_PATH_SIMULATION,
    servers=SERVERS,
    title="GenAI Orchestrator Sample Application",
    description="GenAI Orchestrator Sample Application Description",
    version="beta",
    docs_url=None,
    redoc_url=None,
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"syntaxHighlight.theme": "obsidian"},
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize the collector
ic = InferCollector()


# Define the actual function to provide the collector instance
async def get_actual_collector():
    return ic


# Override the placeholder dependency function with the actual one
app.dependency_overrides[get_collector] = get_actual_collector

# Include the router directly - this will include all routes defined in the router
app.include_router(router)


@app.on_event("startup")
async def app_startup():
    pass


@app.on_event("shutdown")
async def app_shutdown():
    pass


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        reload=True,
        port=PORT,
        host=HOST,
        workers=WORKERS,
        limit_concurrency=LIMIT_CONCURRENCY,
    )
