#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8001}
UV_BIN=${3:-uv}

# ------------------------------------------------------------------
# Custom Package Install Path (Virtual Environment)
# ------------------------------------------------------------------
# Define CUSTOM_VENV_PATH environment variable to override location
# Example: export CUSTOM_VENV_PATH="/project/work/temp/venv"
# Default to /tmp/venv if not set
if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Server] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    
    # Initialize venv if missing
    if [ ! -d "$CUSTOM_VENV_PATH" ]; then
        echo "Creating new virtual environment..."
        # Share system site-packages so awx-* installed in /usr are visible
        $UV_BIN venv --system-site-packages "$CUSTOM_VENV_PATH"
    fi
fi

echo "[Server] Starting App on $HOST:$PORT..."
# Ensure dependencies are installed into the active environment
# Load .env before syncing so uv sees registry/local package settings
if [ -f ".env" ]; then
    set -a
    . .env
    set +a
fi

# If UV_LOCAL_PACKAGES is set but path is missing, ignore it
if [ -n "$UV_LOCAL_PACKAGES" ] && [ ! -d "$UV_LOCAL_PACKAGES" ]; then
    echo "[Flow] UV_LOCAL_PACKAGES path not found: $UV_LOCAL_PACKAGES (ignoring)"
    unset UV_LOCAL_PACKAGES
fi

# If no registry/local packages configured and awx-core is available on system,
# skip uv sync to avoid resolution failure.
if [ -z "$PIP_INDEX_URL" ] && [ -z "$PIP_EXTRA_INDEX_URL" ] && [ -z "$UV_LOCAL_PACKAGES" ]; then
    if python3 - <<'PY' >/dev/null 2>&1
import importlib
import sys
try:
    importlib.import_module("awx.core")
except Exception:
    sys.exit(1)
PY
    then
        echo "[Flow] Skipping uv sync (using system awx-* packages)."
        SKIP_UV_SYNC=1
    fi
fi

if [ -z "$SKIP_UV_SYNC" ]; then
    $UV_BIN sync
fi

# Run App
ARGS="uvicorn main:app --host $HOST --port $PORT"
if [ -n "$ROOT_PATH" ]; then
    ARGS="$ARGS --root-path $ROOT_PATH"
fi

if [ -n "$SKIP_UV_SYNC" ]; then
    # Avoid uv resolver when using system-installed awx-* packages
    python3 -m $ARGS
elif [ -f ".env" ]; then
    $UV_BIN run --env-file .env $ARGS
else
    $UV_BIN run $ARGS
fi
