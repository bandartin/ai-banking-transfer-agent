import os

from awx.observability import InferCollector
from fastapi import APIRouter, Depends, Header, Request, Response
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.responses import FileResponse, StreamingResponse
from internal.client_abc import GeneratorClient
from internal.client_example import ExampleClient
# from internal.client_langchain import LangchainClient
from models import STREAM_RESPONSE_SAMPLE, InputOrch
from utils import get_callback_data

router = APIRouter()


async def get_collector():
    """
    Dependency function that provides an InferenceCollector instance.

    This is a placeholder that will be overridden by the app's dependency_overrides
    in main.py with the actual InferenceCollector instance.

    Returns:
        InferCollector: The collector instance

    Raises:
        NotImplementedError: If the dependency hasn't been properly overridden
    """
    raise NotImplementedError("Collector dependency not provided")


async def get_generator_client() -> GeneratorClient:
    """
    Dependency function that provides a generator client implementation.

    This function allows easy swapping between different client implementations.
    Default implementation is ExampleClient.

    Returns:
        GeneratorClient: An instance of a class implementing the GeneratorClient interface
    """
    return ExampleClient()  # Basic example client
    # return LangchainClient()  # LangChain client.


@router.get("/static/{filename}", include_in_schema=False)
async def get_static(filename):
    """
    Serve static files from the static directory.

    Args:
        filename (str): The name of the static file to serve

    Returns:
        FileResponse: The requested file if it exists
        Response: 404 error if the file doesn't exist
    """
    static_dir = os.path.dirname(os.path.abspath(__file__)) + "/static/"
    filename = static_dir + filename
    if not os.path.isfile(filename):
        return Response(status_code=404)
    return FileResponse(filename)


@router.get("/", include_in_schema=False)
@router.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html(request: Request):
    """
    Serve the custom Swagger UI HTML page.

    Args:
        request (Request): The incoming request object

    Returns:
        HTMLResponse: The Swagger UI HTML page
    """
    return get_swagger_ui_html(
        openapi_url="." + request.app.openapi_url,
        title=request.app.title + " - Swagger UI",
        swagger_js_url="./static/swagger-ui-bundle.js",
        swagger_css_url="./static/swagger-ui.css",
    )


@router.get("/redoc", include_in_schema=False)
async def redoc_html(request: Request):
    """
    Serve the ReDoc HTML documentation page.

    Args:
        request (Request): The incoming request object

    Returns:
        HTMLResponse: The ReDoc HTML page
    """
    return get_redoc_html(
        openapi_url="." + request.app.openapi_url,
        title=request.app.title + " - ReDoc",
        redoc_js_url="./static/redoc.standalone.js",
    )


@router.get("/health", include_in_schema=False)
async def health_check():
    """
    Health check endpoint.

    Returns:
        Response: HTTP 200 status code if the app is healthy
    """
    return Response(status_code=200)


@router.post(
    "/chat",
    response_class=StreamingResponse,
    responses={
        200: {
            "content": {"text/event-stream": {"example": STREAM_RESPONSE_SAMPLE}},
            "description": "Success response",
        },
        503: {},
    },
    tags=["Orchestrator"],
)
async def chat(
    request: Request,
    body: InputOrch,
    ic: InferCollector = Depends(get_collector),
    generator_client: GeneratorClient = Depends(get_generator_client),
    infer_auth_key: str = Header(default=None, alias="Infer-Auth-Key"),
):
    """
    Endpoint for handling chat requests and streaming responses back to the client.

    This function takes the user's question and uses the injected generator client
    to produce a streaming response.

    Args:
        request (Request): The incoming request object
        body (InputOrch): The request body containing the user's question
        ic (InferCollector): The collector instance for logging/metrics
        generator_client (GeneratorClient): The client used to generate responses
        infer_auth_key (str, optional): Authentication key for the inference service

    Returns:
        StreamingResponse: A streaming response with the generated text

    Response Codes:
        200: Success response with streamed content
        503: Service unavailable
    """
    request_dict = body.model_dump()
    callback_data = get_callback_data(request=request, request_body=request_dict, ic=ic)

    question = request_dict.get("question")

    # Now using the injected generator client
    return StreamingResponse(
        generator_client.generate(
            message=question,
            callback=ic,
            callback_data=callback_data,
        ),
        media_type="text/event-stream",
        headers={"X-Accel-Buffering": "no"},
    )
