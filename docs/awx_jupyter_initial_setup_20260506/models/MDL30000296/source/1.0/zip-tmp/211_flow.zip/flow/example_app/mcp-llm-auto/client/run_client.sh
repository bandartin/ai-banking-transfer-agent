#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8000}
UV_BIN=${3:-uv}

# ------------------------------------------------------------------
# Custom Package Install Path (Virtual Environment)
# ------------------------------------------------------------------
# Define CUSTOM_VENV_PATH environment variable to override location
# Example: export CUSTOM_VENV_PATH="/project/work/temp/venv"
# Default to /tmp/venv if not set
if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Client] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    
    # Initialize venv if missing
    if [ ! -d "$CUSTOM_VENV_PATH" ]; then
        echo "Creating new virtual environment..."
        $UV_BIN venv "$CUSTOM_VENV_PATH"
    fi
fi

echo "[Client] Starting MCP Client on $HOST:$PORT..."
# Ensure dependencies are installed into the active environment
$UV_BIN sync

# Run MCP Client with Auto-Instrumentation
# Service Name: mcp-client-auto
# We DISABLE automatic fastapi instrumentation because we manage middleware in code.
OTEL_SERVICE_NAME="INF2026010222" \
# OTEL_PYTHON_DISABLED_INSTRUMENTATIONS="fastapi,starlette" \
$UV_BIN run --env-file .env opentelemetry-instrument \
    uvicorn client:app --host $HOST --port $PORT

# echo "[Client] Running without OTel wrapper to debug transport issues..."
# $UV_BIN run --env-file .env uvicorn client:app --host $HOST --port $PORT
