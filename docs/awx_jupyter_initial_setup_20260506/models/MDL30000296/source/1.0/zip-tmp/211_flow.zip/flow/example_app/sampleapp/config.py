import os

# API configuration
MLDL_SERVICE_CONTEXT_PATH_SIMULATION = os.getenv(
    "MLDL_SERVICE_CONTEXT_PATH_SIMULATION", ""
)

# Proxy ingress settings
SERVERS = []
if MLDL_SERVICE_CONTEXT_PATH_SIMULATION.startswith("/test"):
    SERVERS.append({"url": MLDL_SERVICE_CONTEXT_PATH_SIMULATION, "description": "Test Simulation Service"})
    MLDL_SERVICE_CONTEXT_PATH_SIMULATION = MLDL_SERVICE_CONTEXT_PATH_SIMULATION.replace("/test", "")


# Custom environment variables
CUSTOM_ENV_A = os.environ.get("CUSTOM_ENV_A", "CUSTOM_ENV_VALUE")
CUSTOM_ENV_B = os.environ.get("CUSTOM_ENV_B", "CUSTOM_ENV_VALUE")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# API Documentation settings
TAGS_METADATA = [
    {
        "name": "Orchestrator",
        "description": "GenAI Custom Orchestrator description here",
    },
    {"name": "Sample", "description": "GenAI Custom Orchestrator sample"},
]

# Server settings
PORT = 9101
HOST = "0.0.0.0"
WORKERS = 2
LIMIT_CONCURRENCY = 2
