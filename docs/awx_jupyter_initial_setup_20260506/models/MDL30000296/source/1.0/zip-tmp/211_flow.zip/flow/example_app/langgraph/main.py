import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from opentelemetry import trace

# ===================================================
# OpenTelemetry 자동 계측 사용 시 최소한의 코드
# ===================================================
# opentelemetry-instrument CLI가 자동으로 tracer provider, exporter 설정,
# 그리고 라이브러리 패칭(FastAPI, HTTPX 등)을 처리합니다.
# LangGraph는 LangChain 위에 구축되므로 opentelemetry-instrumentation-langchain이
# LangGraph 실행도 자동으로 추적합니다.

# 라우터 import
from router import router

from opentelemetry.instrumentation.langchain import LangchainInstrumentor

LangchainInstrumentor().instrument()

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# OpenTelemetry 로깅 레벨 조정 (필요시)
logging.getLogger('opentelemetry').setLevel(logging.WARNING)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 시작 시 테스트 span을 생성하여 exporter 체인 검증
    try:
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span("startup_connection_test") as span:
            span.set_attribute("service.startup", "true")
            logger.info("OTEL Startup Test Span Emitted")
            logger.info(f"OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: {os.environ.get('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT')}")
            logger.info(f"OTEL_SERVICE_NAME: {os.environ.get('OTEL_SERVICE_NAME')}")
    except Exception as e:
        logger.error(f"Failed to emit startup span: {e}")
    yield

app = FastAPI(title="LangGraph with OpenTelemetry", lifespan=lifespan)

# 라우터 등록
app.include_router(router, prefix="/langraph", tags=["LangGraph"])

@app.get("/")
async def root():
    return {"message": "LangGraph API Server with OpenTelemetry"}
