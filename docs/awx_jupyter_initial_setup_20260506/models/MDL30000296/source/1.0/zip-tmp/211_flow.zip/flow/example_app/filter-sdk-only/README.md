# Filter SDK Only App

`awx.resources`의 filter(guardrail) SDK만 사용하는 최소 FastAPI 예제입니다.

## 목적

이 예제의 핵심 목적은 아래 2가지입니다.

1. filter SDK 호출이 정상 동작하는지 확인
2. filter 관련 메타데이터(`awx.guardrail.filter.ids`, `awx.guardrail.filter.count`)가 OTel span attribute로 전송되는지 확인

전송 자체는 앱 코드에서 직접 HTTP 전송하지 않고, `opentelemetry-instrument` 런타임이 exporter로 전송합니다.

## 1. 초기화

```bash
cd /home/user/idea-project/container-script/example_awx/flow
make init app=filter-sdk-only
```

## 2. 실행

```bash
make run
```

직접 실행:

```bash
cd /home/user/idea-project/container-script/example_awx/flow/example_app/filter-sdk-only
bash run_app.sh
```

`run_app.sh`는 항상 `opentelemetry-instrument`를 사용해 실행합니다.

필요 환경 변수는 `.env.example`을 참고하세요.

## 3. API 호출 예시

```bash
curl -sS -X POST 'http://127.0.0.1:8001/filter/check' \
  -H 'Content-Type: application/json' \
  -d '{"text":"010-1234-5678","mode":"input","service_id":1}'
```

```bash
curl -sS 'http://127.0.0.1:8001/health'
```

앱 코드는 `Guardrail().get_policies`, `Guardrail().apply` 두 가지 SDK 호출만 수행합니다.
`awx.guardrail.filter.ids`, `awx.guardrail.filter.count`, `awx.guardrail.mode` span attribute 기록은 SDK 내부에서 자동 처리됩니다.
