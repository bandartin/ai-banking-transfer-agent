import json

from dap_gen.common import dap
from dap_gen.text import (
    text as tx,  # 기본적으로 제공되는 TextClient의 instance 'text'입니다. 너무 일반적인 이름이라 여기서는 tx로 바꿔서 사용하고 있습니다.
)

"""
이 샘플 스크립트는 GenAI Text Portal에서 LLM과 Vector DB의 자격 증명을 가져와서 JSON 파일로 저장하는 예제입니다.
다음을 수행합니다:
python3 sample_app.py

실행 이후, flow 디렉토리 하위에 다음의 파일들이 생성됩니다.
- 000_credentials.json: LLM과 Vector DB의 자격 증명이 포함된 JSON 파일입니다.
- external_resources_cache.json: LLM과 Vector DB의 외부 리소스 정보가 포함된 JSON 파일입니다.
- prompts_cache.json: LLM과 Vector DB의 프롬프트 정보가 포함된 JSON 파일입니다.
"""

# KL 서비스는 사용 전에 GenAI Text Portal에 등록되어 있어야 합니다. 관리자 서비스 > 인증/권한 > API 관리에서 관리할 수 있습니다.
vectorstore_resources = dap.get_external_resources("KnowledgeLake", "GENTEXT", service_type_name="VECTORSTORE")
selected_vectorstore = vectorstore_resources[0]  # 실제 시나리오에서는 이것이 원하는 벡터 스토어가 맞는지 먼저 확인해야 합니다.
vector_service_id = selected_vectorstore["serviceId"] # 해당 벡터 스토어의 서비스 ID를 가져옵니다.
vector_service_credentials = dap.get_credentials(vector_service_id) # 서비스 ID를 사용하여 자격 증명을 가져옵니다.

# LLM 서비스는 사용 전에 GenAI Text Portal에 등록되어 있어야 합니다. 관리자 서비스 > 인증/권한 > API 관리에서 관리할 수 있습니다.
llm_resources = dap.get_external_resources("OpenAI", "GENTEXT", service_type_name="LLM")
selected_llm = None  # 기본값으로 초기화합니다.
for i, item in enumerate(
    llm_resources
):  # 모델 별칭에 'mini'가 포함된 항목을 선택합니다.
    if 'mini' in item['modelAlias']:
        selected_llm = llm_resources[i]  # 인덱스 참조를 사용하여 external_reources_cache.json을 생성합니다. item을 직접 사용하는 경우 필요한 파일이 생성되지 않습니다.
        break

if selected_llm is None:
    raise ValueError("No LLM resource with 'mini' in its modelAlias was found.")

llm_service_id = selected_llm["serviceId"]
llm_service_credentials = dap.get_credentials(llm_service_id)

# 자격 증명 JSON 저장
vs_credential = vector_service_credentials[0]
llm_credential = llm_service_credentials[0]

prompts = tx.get_prompts()
print(json.dumps(prompts[0], indent=2, ensure_ascii=False))
