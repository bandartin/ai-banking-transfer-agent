#!/bin/bash
HOST=${1:-0.0.0.0}
PORT=${2:-8001}
UV_BIN=${3:-uv}

# ------------------------------------------------------------------
# Custom Package Install Path (Virtual Environment)
# ------------------------------------------------------------------
if [ -z "$CUSTOM_VENV_PATH" ]; then
    CUSTOM_VENV_PATH="/tmp/venv"
fi

if [ -n "$CUSTOM_VENV_PATH" ]; then
    echo "[Server] Using custom virtual environment at: $CUSTOM_VENV_PATH"
    export UV_PROJECT_ENVIRONMENT="$CUSTOM_VENV_PATH"
    $UV_BIN venv --allow-existing "$CUSTOM_VENV_PATH"
fi

echo "[Server] Starting App on $HOST:$PORT..."
# Check for server dir (common in GUIDE apps)
if [ -d "server" ]; then
    cd server
fi

$UV_BIN sync

# Run App (auto instrumentation configured in app code)
ARGS="python main.py --host $HOST --port $PORT"
if [ -n "$ROOT_PATH" ]; then
    ARGS="$ARGS --root-path $ROOT_PATH"
fi

if [ -f ".env" ]; then
    $UV_BIN run --env-file .env $ARGS
else
    $UV_BIN run $ARGS
fi
