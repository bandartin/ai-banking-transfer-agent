from typing import Optional
import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

# ===================================================
# LangChain imports
# ===================================================
# 주석: LLM은 사용자 환경에 맞게 변경 가능 (OpenAI, Anthropic 등)
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.llms.fake import FakeListLLM

logger = logging.getLogger(__name__)

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    topic: Optional[str] = "일반"

# ===================================================
# OpenTelemetry 자동 계측
# ===================================================
# opentelemetry-instrumentation-langchain이 자동으로
# LangChain의 모든 호출을 추적합니다.
# 추가 코드 수정이 필요 없습니다.

@router.post("/chat/basic")
async def basic_chat(request: ChatRequest):
    """
    기본 LangChain 채팅 예제
    OpenTelemetry가 자동으로 LLM 호출을 추적합니다.
    """
    try:
        # 주석: 모델명과 API 키는 환경 변수 또는 .env 파일에서 설정
        llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)
        messages = [
            SystemMessage(content="당신은 도움이 되는 AI 어시스턴트입니다."),
            HumanMessage(content=request.message)
        ]
        response = llm.invoke(messages)
        return {"response": response.content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/prompt")
async def prompt_template_chat(request: ChatRequest):
    """
    Prompt Template을 사용한 LangChain 예제
    Chain 실행이 자동으로 추적됩니다.
    """
    try:
        prompt = ChatPromptTemplate.from_messages([
            ("system", "당신은 {topic} 전문가입니다."),
            ("human", "{question}")
        ])
        llm = ChatOpenAI(model="gpt-3.5-turbo")
        chain = prompt | llm | StrOutputParser()
        result = chain.invoke({"topic": request.topic, "question": request.message})
        return {"response": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/offline-llm")
async def offline_llm_chat(request: ChatRequest):
    """
    UV_OFFLINE 환경에서 사용할 수 있는 Fake LLM 예제
    Chain 실행이 자동으로 추적됩니다.
    """
    try:
        llm = FakeListLLM(responses=[f"(offline) {request.topic} 관련 응답 예시입니다."])
        prompt = PromptTemplate.from_template("당신은 {topic} 전문가입니다.\n질문: {question}")
        chain = prompt | llm | StrOutputParser()
        result = chain.invoke({"topic": request.topic, "question": request.message})
        return {"response": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/error-test")
async def error_test_chat(request: ChatRequest):
    """
    에러 추적 테스트용 엔드포인트
    OpenTelemetry가 에러 정보를 자동으로 span에 기록하는지 확인
    """
    error_type = request.message.lower()
    try:
        if error_type == "invalid_api_key":
            llm = ChatOpenAI(model="gpt-3.5-turbo", openai_api_key="invalid-key-12345", temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        elif error_type == "invalid_model":
            llm = ChatOpenAI(model="gpt-invalid-model-name-999", temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        elif error_type == "timeout":
            llm = ChatOpenAI(model="gpt-3.5-turbo", timeout=0.001, temperature=0.7)
            messages = [SystemMessage(content="테스트"), HumanMessage(content="안녕하세요")]
            response = llm.invoke(messages)
            return {"response": response.content}
        else:
            raise ValueError(f"테스트 에러: {error_type}")
    except Exception as e:
        logger.error(f"에러 발생 - type: {type(e).__name__}, message: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": type(e).__name__,
                "error_message": str(e),
                "note": "OpenTelemetry instrumentation이 자동으로 error.type과 error.message를 span에 기록하는지 확인하세요"
            }
        )

@router.get("/")
async def root():
    return {"message": "LangChain Router works!"}
