from datetime import datetime
import textwrap

from dap_gen.common import dap
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from .client_abc import GeneratorClient

# =================================================================================================
# DAP-GEN SDK Implementation for Text Generation
# =================================================================================================


class LangchainClient(GeneratorClient):
    def __init__(self):
        # 1. Prepare prompts
        self.document_qa_template = textwrap.dedent("""
        You are a helpful assistant that answers questions based on the provided documents.

        Document:
        {document}

        Question: {question}

        Answer the question using only information from the document above. If the document doesn't provide the information needed to answer the question, acknowledge this, and then proceed to answer the question to the best of your knowledge. If the document contains the answer, provide a concise and accurate answer based on the information in the document.

        Answer:
        """).strip()
        self.document_qa_prompt = PromptTemplate.from_template(
            self.document_qa_template
        )

        # 2. Set up OpenAI credentials
        exts = dap.get_external_resources(
            provider_alias="OpenAI", solution_id="GENTEXT", service_type_name="llm"
        )
        credential_idx = 0
        for idx, item in enumerate(exts):
            if "mini" in item["modelAlias"]:
                credential_idx = idx
                break
        resource = exts[credential_idx]
        credentials = dap.get_credentials(
            resource['serviceId']
        )  # Get credentials by service Id
        api_key = credentials[0]["variables"][0]["attributeValue"]  # Extract API key
        self.llm = ChatOpenAI(api_key=api_key)

        # 2. Load document
        self.document = """
        This is a sample document. It contains information about various topics.
        You can ask questions based on this document.
        """

        # 3. Create chains
        self.document_qa_chain = self.document_qa_prompt | self.llm

    def generate(self, message, callback=None, callback_data=None):
        """
        Generate text responses based on input message and optional document.

        Args:
            message: User question
            callback: Callback for result tracking
            callback_data: Data for callback processing
        """
        # Select appropriate chain based on whether document is provided
        response = self.document_qa_chain.stream(
            {"question": message, "document": self.document}
        )

        generated_text = ""

        for token in response:
            if not token.response_metadata:
                generated_text += token.content
                yield f'data: {{"token": {{"text": "{token.content}", "special": false}}, "generated_text": null}}\n\n'
            else:
                yield f'data: {{"token": {{"text": null, "special": true}}, "generated_text": "{generated_text}"}}\n\n'

        # Process callback if provided and active
        if callback and callback.use_yn:
            callback.push_result_to_queue(
                model_id=callback_data.get("model_id"),
                model_ver=callback_data.get("model_ver"),
                process_start_time=callback_data.get("start_time"),
                process_end_time=datetime.now(),
                request_header=callback_data.get("request_header"),
                request_body=callback_data.get("request_body"),
                response_header={"content-type": "text/event-stream"},
                response_body={"result": generated_text},
                client_ip=callback_data.get("client_ip"),
                api_url=callback_data.get("api_url"),
            )
