from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from opentelemetry import trace
import uvicorn
from awx.resources import Credential

from awx.observability.instrumentation.fastapi import (
    instrument_app,
)
from awx.observability.instrumentation.resource_attributes import (
    build_resource_attributes,
)
from chat_service import _execute_chat
from credential_defaults import DEFAULT_CREDENTIAL_PREFETCH_HINTS
from credential_defaults import DEFAULT_CREDENTIAL_SERVICE_ID
from schemas import ChatRequest

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("awx-observability-client")
UNKNOWN_SERVICE_NAME = "unknown"


def _env_flag(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _resolve_service_name() -> str:
    try:
        provider = trace.get_tracer_provider()
        resource = getattr(provider, "resource", None)
        if resource is not None:
            candidate = resource.attributes.get("service.name")
            if isinstance(candidate, str) and candidate.strip():
                return candidate.strip()
    except Exception:
        pass

    try:
        attrs = build_resource_attributes()
        candidate = attrs.get("service.name")
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    except Exception:
        pass
    return UNKNOWN_SERVICE_NAME


def _prefetch_external_resources(provider_alias: str, service_type_name: str) -> None:
    try:
        from awx.common import config as awx_config
        from awx.resources.external_resources import ExternalResource, _external_resources_storage
    except Exception as exc:
        logger.debug(
            "External resource prefetch skipped (import failed): provider=%s service_type=%s error=%s",
            provider_alias,
            service_type_name,
            exc,
        )
        return

    try:
        ext_res = ExternalResource()
        resources = ext_res.get(
            provider_alias=provider_alias,
            solution_id=awx_config.PLATFORM_CODE,
            service_type_name=service_type_name,
        )
        normalized = [item for item in resources if isinstance(item, dict)]
        # In inference mode, ExternalResource.get() reads file cache but does not
        # populate in-process storage used by metric attribute resolution.
        storage_key = f"{provider_alias}_{awx_config.PLATFORM_CODE}_{service_type_name}_"
        _external_resources_storage[storage_key] = normalized
        logger.info(
            "External resources prefetched: provider=%s service_type=%s count=%d",
            provider_alias,
            service_type_name,
            len(normalized),
        )
    except Exception as exc:
        logger.warning(
            "External resource prefetch failed: provider=%s service_type=%s error=%s",
            provider_alias,
            service_type_name,
            exc,
        )


def _prefetch_credentials() -> None:
    if not _env_flag("AWX_CREDENTIAL_PREFETCH", default=True):
        logger.info("Credential prefetch disabled by AWX_CREDENTIAL_PREFETCH")
        return

    credential_client = Credential()
    for provider_alias, service_type_name in DEFAULT_CREDENTIAL_PREFETCH_HINTS:
        _prefetch_external_resources(provider_alias, service_type_name)
        try:
            credentials = credential_client.get(
                service_id=DEFAULT_CREDENTIAL_SERVICE_ID,
                provider_alias=provider_alias,
                service_type_name=service_type_name,
            )
            selected = None
            find_and_cache = getattr(credentials, "find_and_cache", None)
            if callable(find_and_cache):
                selected = find_and_cache(lambda _item: True)
            elif hasattr(credentials, "__len__") and len(credentials) > 0:
                selected = credentials[0]
            count = len(credentials) if hasattr(credentials, "__len__") else -1
            if count >= 0:
                logger.info(
                    "Credential prefetched: provider=%s service_type=%s count=%d selected=%s",
                    provider_alias,
                    service_type_name,
                    count,
                    "yes" if selected is not None else "no",
                )
            else:
                logger.info(
                    "Credential prefetched: provider=%s service_type=%s selected=%s",
                    provider_alias,
                    service_type_name,
                    "yes" if selected is not None else "no",
                )
        except Exception as exc:
            logger.warning(
                "Credential prefetch failed for provider=%s service_type=%s: %s",
                provider_alias,
                service_type_name,
                exc,
            )


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=== AWX Observability MCP Client Starting ===")
    logger.info("SERVICE_NAME: %s", _resolve_service_name())
    logger.info("MCP_SERVER_URL: %s", os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8001/mcp/sse"))
    _prefetch_credentials()
    try:
        logger.info("AWX_RESOURCE_ATTRS: %s", build_resource_attributes())
    except Exception as exc:  # pragma: no cover - diagnostic only
        logger.warning("Failed to build AWX resource attributes: %s", exc)
    try:
        provider = trace.get_tracer_provider()
        resource = getattr(provider, "resource", None)
        if resource is not None:
            logger.info("OTEL_PROVIDER_RESOURCE_ATTRS: %s", resource.attributes)
    except Exception as exc:  # pragma: no cover - diagnostic only
        logger.warning("Failed to read tracer provider resource attributes: %s", exc)
    yield
    logger.info("=== AWX Observability MCP Client Shutting Down ===")


app = FastAPI(
    title="AWX Observability MCP Client",
    description="AWX observability client with MCP call + OTEL response payload",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

instrument_app(app)

cors_origins = os.getenv("CORS_ALLOW_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in cors_origins if origin.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/chat", response_model=None)
async def chat(request: ChatRequest) -> dict[str, Any] | StreamingResponse:
    return await _execute_chat(request)


@app.get("/health")
async def health_check() -> dict[str, Any]:
    return {
        "status": "healthy",
        "service_name": _resolve_service_name(),
        "mcp_server_url": os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8001/mcp/sse"),
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
