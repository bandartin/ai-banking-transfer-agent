from __future__ import annotations

import argparse
from contextlib import contextmanager
import os
from typing import Any, Iterator, Literal

from fastapi import FastAPI, Header
from fastapi.responses import StreamingResponse
from opentelemetry import trace
from pydantic import BaseModel, Field

from awx.resources import Guardrail


@contextmanager
def _fake_llm_parent_span():
    get_tracer = getattr(trace, "get_tracer", None)
    if not callable(get_tracer):
        yield None
        return
    try:
        tracer = get_tracer("filter-sdk-only")
        with tracer.start_as_current_span("awx.llm.fake") as span:
            if hasattr(span, "set_attribute"):
                span.set_attribute("awx.llm.name", "fake")
                span.set_attribute("awx.llm.synthetic", "true")
            yield span
    except Exception:
        # Keep example endpoint usable even when tracer is unavailable/mocked.
        yield None


class FilterCheckRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Text to be checked by filter SDK")
    mode: str = Field(default="input", description="input | output")
    service_id: int = Field(default=1, ge=1, description="Guardrail service id")


class TwoLlmE2ERequest(BaseModel):
    llm1_input: str = Field(..., min_length=1, description="First LLM input text")
    llm2_input: str = Field(..., min_length=1, description="Second LLM input text")
    llm1_policy_id: int = Field(default=6, ge=0, description="LLM1 guardrail policy id")
    llm2_policy_id: int = Field(default=7, ge=0, description="LLM2 guardrail policy id")


class TwoLlmStreamE2ERequest(BaseModel):
    llm1_input: str = Field(..., min_length=1, description="First LLM input text")
    llm2_input: str = Field(..., min_length=1, description="Second LLM input text")
    llm1_policy_id: int = Field(default=6, ge=0, description="LLM1 guardrail policy id")
    llm2_policy_id: int = Field(default=7, ge=0, description="LLM2 guardrail policy id")
    chunk_size: int = Field(default=32, ge=1, description="Stream push chunk size")
    overlap_tokens: int = Field(default=8, ge=0, description="Stream overlap tokens")
    holdback_tokens: int = Field(default=16, ge=0, description="Stream holdback tokens")


class OneLlmStreamRequest(BaseModel):
    message: str = Field(..., min_length=1, description="Single LLM input text")
    input_policy_id: int = Field(default=6, ge=0, description="Input guardrail policy id")
    output_policy_id: int = Field(default=7, ge=0, description="Output guardrail policy id")
    chunk_size: int = Field(default=8, ge=1, description="Stream push chunk size")
    overlap_tokens: int = Field(default=8, ge=0, description="Stream overlap tokens")
    holdback_tokens: int = Field(default=16, ge=0, description="Stream holdback tokens")


def _run_filter_check(
    text: str,
    mode: str,
    service_id: int,
) -> dict[str, Any]:
    guardrail = Guardrail()
    policies = guardrail.get_policies()
    with _fake_llm_parent_span():
        output_text, status = guardrail.apply(
            input_text=text,
            policy_id=0,
            mode=mode,
        )

    return {
        "service_id": service_id,
        "mode": mode,
        "policy_count": len(policies) if isinstance(policies, list) else None,
        "filter_result": {
            "output_text": output_text,
            "status": status,
        },
    }


def _trace_id_hex(span: Any) -> str:
    context = span.get_span_context()
    if context is None or not getattr(context, "is_valid", False):
        return ""
    return f"{context.trace_id:032x}"


def _invoke_llm(*, model_name: str, prompt: str) -> str:
    return f"{model_name} response: {prompt}"


def _split_chunks(text: str, chunk_size: int) -> list[str]:
    if chunk_size <= 0:
        return [text]
    return [text[i : i + chunk_size] for i in range(0, len(text), chunk_size)] or [""]


def _invoke_llm_openai_stream(
    *,
    model_name: str,
    prompt: str,
    chunk_size: int,
) -> Iterator[dict[str, Any]]:
    # OpenAI Chat Completions stream-like payload shape.
    llm_text = _invoke_llm(model_name=model_name, prompt=prompt)
    for chunk in _split_chunks(llm_text, chunk_size):
        yield {
            "choices": [
                {
                    "delta": {
                        "content": chunk,
                    }
                }
            ]
        }


def _prepare_one_llm_stream(
    *,
    message: str,
    input_policy_id: int = 6,
    output_policy_id: int = 7,
    chunk_size: int = 8,
    overlap_tokens: int = 8,
    holdback_tokens: int = 16,
) -> tuple[dict[str, Any], Iterator[str]]:
    guardrail = Guardrail()
    policies = guardrail.get_policies()
    trace_id = _trace_id_hex(trace.get_current_span())

    guarded_input, input_status = guardrail.apply_stream(
        input_text=message,
        policy_id=input_policy_id,
        mode="input",
        chunk_size=chunk_size,
        overlap_tokens=overlap_tokens,
        holdback_tokens=holdback_tokens,
    )
    llm_output = _invoke_llm(model_name="llm1", prompt=guarded_input)
    stream = guardrail.iter_stream(
        input_text=llm_output,
        policy_id=output_policy_id,
        mode="output",
        chunk_size=chunk_size,
        overlap_tokens=overlap_tokens,
        holdback_tokens=holdback_tokens,
    )
    metadata = {
        "trace_id": trace_id,
        "policy_count": len(policies) if isinstance(policies, list) else None,
        "input_status": input_status,
        "input_policy_id": input_policy_id,
        "output_policy_id": output_policy_id,
    }
    return metadata, stream


def _run_two_llm_e2e(
    *,
    llm1_input: str,
    llm2_input: str,
    llm1_policy_id: int = 6,
    llm2_policy_id: int = 7,
) -> dict[str, Any]:
    guardrail = Guardrail()
    policies = guardrail.get_policies()
    trace_id = _trace_id_hex(trace.get_current_span())

    with _fake_llm_parent_span():
        llm1_guarded_in, llm1_input_status = guardrail.apply(
            input_text=llm1_input,
            policy_id=llm1_policy_id,
            mode="input",
        )
        llm1_output = _invoke_llm(model_name="llm1", prompt=llm1_guarded_in)
        llm1_guarded_out, llm1_output_status = guardrail.apply(
            input_text=llm1_output,
            policy_id=llm1_policy_id,
            mode="output",
        )

    llm2_guarded_in, llm2_input_status = guardrail.apply(
        input_text=llm2_input,
        policy_id=llm2_policy_id,
        mode="input",
    )
    llm2_output = _invoke_llm(
        model_name="llm2",
        prompt=f"{llm1_guarded_out} || {llm2_guarded_in}",
    )
    final_output, llm2_output_status = guardrail.apply(
        input_text=llm2_output,
        policy_id=llm2_policy_id,
        mode="output",
    )

    return {
        "trace_id": trace_id,
        "policy_count": len(policies) if isinstance(policies, list) else None,
        "llm1": {
            "policy_id": llm1_policy_id,
            "input_status": llm1_input_status,
            "output_status": llm1_output_status,
        },
        "llm2": {
            "policy_id": llm2_policy_id,
            "input_status": llm2_input_status,
            "output_status": llm2_output_status,
        },
        "final_output": final_output,
    }


def _run_two_llm_stream_e2e(
    *,
    llm1_input: str,
    llm2_input: str,
    llm1_policy_id: int = 6,
    llm2_policy_id: int = 7,
    chunk_size: int = 32,
    overlap_tokens: int = 8,
    holdback_tokens: int = 16,
) -> dict[str, Any]:
    guardrail = Guardrail()
    policies = guardrail.get_policies()
    trace_id = _trace_id_hex(trace.get_current_span())

    with _fake_llm_parent_span():
        llm1_guarded_in, llm1_input_status = guardrail.apply_stream_iter(
            input_chunks=iter(_split_chunks(llm1_input, chunk_size)),
            policy_id=llm1_policy_id,
            mode="input",
            chunk_size=chunk_size,
            overlap_tokens=overlap_tokens,
            holdback_tokens=holdback_tokens,
        )
        llm1_events = _invoke_llm_openai_stream(
            model_name="llm1",
            prompt=llm1_guarded_in,
            chunk_size=chunk_size,
        )
        llm1_guarded_out, llm1_output_status = guardrail.apply_openai_stream(
            events=llm1_events,
            policy_id=llm1_policy_id,
            mode="output",
            chunk_size=chunk_size,
            overlap_tokens=overlap_tokens,
            holdback_tokens=holdback_tokens,
        )

    llm2_guarded_in, llm2_input_status = guardrail.apply_stream_iter(
        input_chunks=iter(_split_chunks(llm2_input, chunk_size)),
        policy_id=llm2_policy_id,
        mode="input",
        chunk_size=chunk_size,
        overlap_tokens=overlap_tokens,
        holdback_tokens=holdback_tokens,
    )
    llm2_prompt = f"{llm1_guarded_out} || {llm2_guarded_in}"
    llm2_events = _invoke_llm_openai_stream(
        model_name="llm2",
        prompt=llm2_prompt,
        chunk_size=chunk_size,
    )
    final_output, llm2_output_status = guardrail.apply_openai_stream(
        events=llm2_events,
        policy_id=llm2_policy_id,
        mode="output",
        chunk_size=chunk_size,
        overlap_tokens=overlap_tokens,
        holdback_tokens=holdback_tokens,
    )

    return {
        "trace_id": trace_id,
        "policy_count": len(policies) if isinstance(policies, list) else None,
        "llm1": {
            "policy_id": llm1_policy_id,
            "input_status": llm1_input_status,
            "output_status": llm1_output_status,
        },
        "llm2": {
            "policy_id": llm2_policy_id,
            "input_status": llm2_input_status,
            "output_status": llm2_output_status,
        },
        "final_output": final_output,
    }


app = FastAPI(
    title="Filter SDK Only Example",
    description="Minimal FastAPI app using only awx.resources filter SDK APIs.",
    version="0.1.0",
)


@app.get("/")
async def root() -> dict[str, Any]:
    return {
        "app": "filter-sdk-only",
        "message": "Use POST /filter/check, /e2e/two-llm, /e2e/two-llm-stream, or /e2e/one-llm-stream.",
    }


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
    }


@app.post("/filter/check")
async def filter_check(request: FilterCheckRequest) -> dict[str, Any]:
    return _run_filter_check(
        text=request.text,
        mode=request.mode,
        service_id=request.service_id,
    )


@app.post("/e2e/two-llm")
async def e2e_two_llm(
    request: TwoLlmE2ERequest,
    include_stream: Literal["0", "1"] = Header(
        default="0",
        alias="X-AWX-Stream-Include",
        description="0 | 1 (기본값 0=off, 1=on; on이면 stream guardrail 경로 사용)",
    ),
) -> dict[str, Any]:
    if include_stream == "1":
        return _run_two_llm_stream_e2e(
            llm1_input=request.llm1_input,
            llm2_input=request.llm2_input,
            llm1_policy_id=request.llm1_policy_id,
            llm2_policy_id=request.llm2_policy_id,
        )
    return _run_two_llm_e2e(
        llm1_input=request.llm1_input,
        llm2_input=request.llm2_input,
        llm1_policy_id=request.llm1_policy_id,
        llm2_policy_id=request.llm2_policy_id,
    )


@app.post("/e2e/two-llm-stream")
async def e2e_two_llm_stream(request: TwoLlmStreamE2ERequest) -> dict[str, Any]:
    return _run_two_llm_stream_e2e(
        llm1_input=request.llm1_input,
        llm2_input=request.llm2_input,
        llm1_policy_id=request.llm1_policy_id,
        llm2_policy_id=request.llm2_policy_id,
        chunk_size=request.chunk_size,
        overlap_tokens=request.overlap_tokens,
        holdback_tokens=request.holdback_tokens,
    )


@app.post("/e2e/one-llm-stream")
async def e2e_one_llm_stream(request: OneLlmStreamRequest) -> StreamingResponse:
    metadata, stream = _prepare_one_llm_stream(
        message=request.message,
        input_policy_id=request.input_policy_id,
        output_policy_id=request.output_policy_id,
        chunk_size=request.chunk_size,
        overlap_tokens=request.overlap_tokens,
        holdback_tokens=request.holdback_tokens,
    )
    headers = {
        "X-AWX-Trace-Id": metadata.get("trace_id", ""),
        "X-AWX-Input-Status": metadata.get("input_status", ""),
        "X-AWX-Input-Policy-Id": str(metadata.get("input_policy_id", "")),
        "X-AWX-Output-Policy-Id": str(metadata.get("output_policy_id", "")),
    }
    if metadata.get("policy_count") is not None:
        headers["X-AWX-Policy-Count"] = str(metadata["policy_count"])
    return StreamingResponse(
        stream,
        media_type="text/plain; charset=utf-8",
        headers=headers,
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8000")))
    parser.add_argument("--root-path", default=os.getenv("ROOT_PATH", ""))
    return parser.parse_args()


if __name__ == "__main__":
    import uvicorn

    args = _parse_args()
    uvicorn.run(app, host=args.host, port=args.port, root_path=args.root_path)
