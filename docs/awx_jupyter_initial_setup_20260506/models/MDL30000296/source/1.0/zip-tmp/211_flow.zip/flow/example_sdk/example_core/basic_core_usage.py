"""
awx-core SDK Format Usage Example
"""

from awx.core import Logger, Config

def main():
    print("=== AWX Core Usage Example ===\n")
    
    # 1. Logger 사용 (PascalCase 클래스)
    logger = Logger()
    logger.info("Core Logger initialized.")
    
    # 2. Config 사용 (PascalCase로 통일감 부여)
    print(f"Project ID from Config: {Config.PROJECT_ID}")
    print(f"MLDL Base URL: {Config.MLDL_BASE_URL}")
    
    logger.info(f"STATUS=SUCCESS|ACTION=CORE_TEST|PROJECT={Config.PROJECT_ID}")
    
    print("\n✓ Used SDK Format: from awx.core import Logger, Config")

if __name__ == "__main__":
    main()
