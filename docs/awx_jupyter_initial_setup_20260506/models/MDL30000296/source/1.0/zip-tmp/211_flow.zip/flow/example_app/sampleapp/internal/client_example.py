from datetime import datetime

from .client_abc import GeneratorClient

# =================================================================================================
# Basic Example
# =================================================================================================
_response = "한국의 수도는 **서울특별시**입니다. 서울은 대한민국의 정치, 경 제, 사회, 교통의 중심지입니다. 서울은 한강이 도시를 관통하며, 다양한 역사적 유적지와 현대적인 도시 기능을 겸비한 도시입니다."


class ExampleClient(GeneratorClient):
    def generate(self, message, callback=None, callback_data=None):
        # yield predetermined _response for testing

        accumulator = ""
        # split _response into tokens
        for token in _response.split():
            accumulator += token
            yield (
                'data: {"token": {"text": "%s", "special":false}, "generated_text": null}\n\n'
                % (token)
            )

        yield (
            'data: {"token": {"text": null, "special":true}, "generated_text": "%s"}\n\n'
            % (accumulator)
        )

        # send the inference result to the callback
        if callback and callback.use_yn:
            callback.push_result_to_queue(
                model_id=callback_data.get("model_id"),
                model_ver=callback_data.get("model_ver"),
                process_start_time=callback_data.get("start_time"),
                process_end_time=datetime.now(),
                request_header=callback_data.get("request_header"),
                request_body=callback_data.get("request_body"),
                response_header={"content-type": "text/event-stream"},
                response_body={"result": accumulator},
                client_ip=callback_data.get("client_ip"),
                api_url=callback_data.get("api_url"),
            )
